# -*- coding:utf-8 -*-

import gym

# key 입력을 받기 위해 가장 쉽게 사용할 수 있는 package
import readchar

# 호수의 크기, 바람부는지의 여부 등의 설정
from gym.envs.registration import register


LEFT = 0
DOWN = 1
RIGHT = 2
UP = 3

arrow_key = {
    '\x1b[A': UP,
    '\x1b[B': DOWN,
    '\x1b[C': RIGHT,
    '\x1b[D': LEFT
}

# v3 : 미끄럼 방지(is_slippery)를 사용할 수 있음
# v0 : stochastic
register(
    id='FrozenLake-v3',
    entry_point='gym.envs.toy_text:FrozenLakeEnv',
    kwargs={'map_name': '4x4', 'is_slippery': False}
)

# v0으로 변경
env = gym.make('FrozenLake-v0')
env.reset()
env.render()

while True:
    key = readchar.readkey()
    if key not in arrow_key.keys():
        print(key, ': 잘못된 키를 입력하여 종료합니다...')
        break

    action = arrow_key[key]
    state, reward, done, info = env.step(action)
    env.render()
    print('state: {}, action: {}, reward: {}, done: {}'.format(state, action, reward, done))
    
    if done:
        print('받은 reward: {}'.format(reward))
        break
