# key 입력 문제로 인하여 jupyter notebook에서 정상적으로 실행 불가
# cmd에서 실행
# -*- coding:utf-8 -*-

import gym

# key 입력을 받기 위해 가장 쉽게 사용할 수 있는 package
import readchar

# 호수의 크기, 바람부는지의 여부 등의 설정
from gym.envs.registration import register


# MACRO 정의 
# key 입력 -> 0: 왼쪽 / 1 : 아래쪽 / 2: 오른쪽 / 3: 위쪽 (왼쪽부터 반시계 방향)으로 맵핑
# 액션으로 전달될 숫자
LEFT = 0
DOWN = 1
RIGHT = 2
UP = 3

# Key Mapping (unicode 입력을 숫자로)
arrow_key = {
    '\x1b[A': UP,
    '\x1b[B': DOWN,
    '\x1b[C': RIGHT,
    '\x1b[D': LEFT
}

# FrozenLake 설정 등록
# v3 : 바람 없음 / v0 : 바람 있음
# kwargs 옵션값 : size, 미끌어지다(바람분다)
register(
    id='FrozenLake-v3',
    entry_point='gym.envs.toy_text:FrozenLakeEnv',
    kwargs={'map_name': '4x4', 'is_slippery': False}
)

# 환경 생성 (Environment)
env = gym.make('FrozenLake-v3')

# 환경 초기화 작업 진행 (action을 수행하기 전 초기화)
env.reset()

# 현재 state 출력
env.render()

# 반복적으로 key를 받아서 움직이기
while True:
    key = readchar.readkey()
    # 화살표 키가 아닌 다른 키를 입력한 경우
    if key not in arrow_key.keys():
        print(key, ': 잘못된 키를 입력하여 종료합니다...')
        break

    # action을 결정 (environment에 들어갈 값)
    # 입력된 키값에 맞는 숫자 -> 나중에는 자동으로 찾을 수 있도록 계산해야 함
    action = arrow_key[key]

    # state : 숫자
    # reward : G에 도착하면 1 or 0
    # done : True or False
    state, reward, done, info = env.step(action)
    env.render()
    print('state: {}, action: {}, reward: {}, done: {}'.format(state, action, reward, done))
    
    if done:
        print('받은 reward: {}'.format(reward))
        break
