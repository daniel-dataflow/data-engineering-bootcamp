package stream02.nio;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class File04 {

    void main() {
        String dirPath = "./";

        List<Path> txtFiles = listTxtFiles(dirPath);

        if (txtFiles != null) {
            txtFiles.forEach(File04::printFileAttributes);
        }
    }

    public static List<Path> listTxtFiles(String dirPath) {
        try (Stream<Path> paths = Files.list(Path.of(dirPath))) {
            var txtFiles = paths
                    .filter(p -> p.toString().endsWith(".txt"))
                    .collect(Collectors.toList());

            return txtFiles;

        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void printFileAttributes(Path path) {
        try {
            BasicFileAttributes attrs = Files.readAttributes(path, BasicFileAttributes.class);
            IO.println("name : \t" + path.getFileName());
            IO.println("size : \t" + attrs.size() + " bytes");
            IO.println("createdAt : \t" + attrs.creationTime());
            IO.println("modifiedAt : \t" + attrs.lastModifiedTime());
            IO.println("isDirectory : \t" + attrs.isDirectory());
            IO.println();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
