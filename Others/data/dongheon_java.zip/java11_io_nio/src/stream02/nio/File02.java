package stream02.nio;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.List;

public class File02 {
    void main() {
        write();

        // stream01.io/file06에 대응
        readUsingBuffer("test06.txt");
    }

    public static void write() {
        Path path = Path.of("test06.txt");
        var lines = List.of("new io", "file", "standard open option");

        try {
            // CREATE: 없으면 생성, APPEND: 이어쓰기, SYNC: 쓰기 작업 시 저장장치와 동기화
            Files.write(path, lines,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.APPEND);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void readUsingBuffer(String fileName) {
        try {
            // 내부적으로 try-with-resources 사용
            Files.lines(Path.of(fileName)).forEach(IO::println);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
