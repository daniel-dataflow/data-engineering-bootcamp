package stream02.nio;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class File01 {
    void main() {
        walkingDir();
    }

    public static void walkingDir() {
        Path startPath = Paths.get("./");

        try (Stream<Path> stream = Files.walk(startPath)) {
            stream.forEach(path -> {
                String type = Files.isDirectory(path) ? "[d]" : "[f]";
                int depth = path.getNameCount() - startPath.getNameCount();
                IO.println("\t".repeat(Math.max(0, depth)) + type + " " + path.getFileName());
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /*
    io : input / output stream
    nio : new io

    io                          nio
    stream : 단방향              channel(buffer) : 양방향
    blocking                    non-blocking
    thread 1 = connection 1     thread 1 = n channels (selector 사용)

    Virtual Thread 가 나온 이후 : thread resource (context switching 비용, memory 등) 가 거의 0 이라서 단순한 io로 사용 가능
     */
}
