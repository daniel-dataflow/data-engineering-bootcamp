package stream02.nio;

import java.io.IOException;
import java.nio.file.*;

import static java.nio.file.StandardWatchEventKinds.*;

public class File05 {
    void main() {
        // 아무 txt 파일 삭제, 수정 (= event) 해보면 이벤트 찾아와줌 (= watch)
        watchDirectory("./");
    }

    public static void watchDirectory(String dirPath) {
        try (WatchService watchService = FileSystems.getDefault().newWatchService()) {
            Path path = Path.of(dirPath);
            path.register(watchService, ENTRY_CREATE, ENTRY_DELETE, ENTRY_MODIFY);

            System.out.println("디렉토리 감시 시작: " + dirPath);

            while (true) {
                WatchKey key = watchService.take();
                for (WatchEvent<?> event : key.pollEvents()) {
                    System.out.println(event.kind() + " : " + event.context());
                }
                key.reset();
            }

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
