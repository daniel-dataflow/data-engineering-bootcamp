package stream02.nio;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

public class File03 {
    void main() {
        String inputFile = "test06.txt";
        String outputFile = "test07.txt";

        convertToUpperCase(inputFile, outputFile);
        File02.readUsingBuffer(outputFile);
    }

    public static void convertToUpperCase(String inputFile, String outputFile) {
        try (FileChannel inChannel = FileChannel.open(Path.of(inputFile), StandardOpenOption.READ);
             FileChannel outChannel = FileChannel.open(Path.of(outputFile),
                     StandardOpenOption.CREATE, StandardOpenOption.WRITE)) {

            ByteBuffer buffer = ByteBuffer.allocate(1024);

            while (inChannel.read(buffer) > 0) {
                buffer.flip();
                for (int i = 0; i < buffer.limit(); i++) {
                    byte b = buffer.get(i);
                    if (b >= 'a' && b <= 'z') {
                        // 소문자를 대문자로 변환
                        buffer.put(i, (byte) (b - 32));
                    }
                }
                outChannel.write(buffer);
                buffer.clear();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
