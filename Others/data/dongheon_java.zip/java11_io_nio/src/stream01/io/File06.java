package stream01.io;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

// file05 복붙해서 수정하기
public class File06 {
    void main() {
        // write();
        writeList();
        // read();
        readUsingBuffer01();
        readUsingBuffer02();
    }

    public static void write() {
        // append: true -> 이어쓰기
        try (FileWriter fw = new FileWriter("test05.txt", true)) {
            fw.write("Hello, Java!\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void read() {
        try (FileReader fr = new FileReader("test05.txt")) {
            int i;
            while ((i = fr.read()) != -1) {
                IO.print((char) i);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void writeList() {
        var messages = List.of("Hello\n", "World\n", "java\n");

        try (FileWriter file = new FileWriter("test05.txt", true)) {
            for (String line : messages) {
                file.write(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Buffered Stream : 보조스트림
    public static void readUsingBuffer01() {
        try (BufferedReader br = new BufferedReader(new FileReader("test05.txt"))) {
            String line;
            // readLine() : 한 줄씩 읽어서 리턴 / 끝에 도달하면 null 리턴
            while ((line = br.readLine()) != null) {
                IO.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void readUsingBuffer02() {
        try (BufferedReader br = new BufferedReader(new FileReader("test05.txt"))) {
            // br.lines()는 파일의 각 줄을 Stream<String> 으로 리턴
            br.lines().forEach(IO::println);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /*
    input / output stream의 분류
    - 종류에 따라
        Byte Stream : 이미지, 영상 등 이진 데이터 (1byte)
        Character Stream : 텍스트 데이터 (2byte) -> 내부적으로 1byte 를 2byte로 변환 (encoding 고려)
    - 역할에 따라
        Node Stream (기본 스트림) : file, network에 직접 연결
        Filter Stream (보조 스트림) : 기본 스트림에 추가적인 기능  -> stream chaining
                                    new BufferedReader(new FileReader("test05.txt")))
     */
}