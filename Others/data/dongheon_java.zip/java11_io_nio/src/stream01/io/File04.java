package stream01.io;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class File04 {
    void main() {
        write();
        read();
    }

    public static void write() {
        // try with resources : try(...) 안에 선언하면 블록이 끝날 때 자동으로 close() 호출
        try (FileWriter fw = new FileWriter("test03.txt")) {
            fw.write("Hello, Java!\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void read() {
        try (FileReader fr = new FileReader("test03.txt")) {
            int i;
            while ((i = fr.read()) != -1) {
                System.out.print((char) i);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}