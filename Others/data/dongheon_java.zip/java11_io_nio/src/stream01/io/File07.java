package stream01.io;

import java.io.*;

public class File07 {
    void main() {
        String fileName = "a.png";

        byte[] imageBytes = readImage(fileName);
        if (imageBytes != null) {
            writeImage(imageBytes, "b.png");
        }
    }

    public static byte[] readImage(String file) {
        try (BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file))) {
            byte[] buffer = bis.readAllBytes();
            IO.println(file + "\t length: " + buffer.length);

            return buffer;

        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void writeImage(byte[] imageBytes, String outputFile) {
        try (BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(outputFile))) {
            bos.write(imageBytes);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
