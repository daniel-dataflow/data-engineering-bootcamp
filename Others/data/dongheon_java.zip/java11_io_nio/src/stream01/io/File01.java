package stream01.io;

import java.io.File;

public class File01 {
    void main() {
        walkingDir();
    }

    public static void walkingDir() {
        /*
          / : 최상위 폴더 (directory)
         ./ : 현재 폴더
        ../ : 상위 폴더
        */

        File root = new File("/");
        if (!root.exists()) {
            System.out.println("폴더가 존재하지 않습니다.");
            return;
        }

        File[] files = root.listFiles();
        if (files != null) {
            for (File f : files) {
                if (f.isDirectory()) {
                    IO.println("[DIR]  " + f.getName());
                } else if (f.isFile()) {
                    IO.println("[FILE] " + f.getName());
                }
            }
        }
    }
}
