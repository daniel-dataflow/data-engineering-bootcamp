package stream01.io;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class File02 {
    void main() {
        write();
        read();
    }

    public static void write() {
        FileWriter fw = null;
        try {
            fw = new FileWriter("test01.txt");
            fw.write("Hello, World!\n");

        } catch (IOException e) {
            e.printStackTrace();

        } finally {
            try {
                if (fw != null) {
                    fw.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    public static void read() {
        FileReader fr = null;

        try {
            fr = new FileReader("test01.txt");
            int i;

            // -1 : file의 끝을 의미
            while ((i = fr.read()) != -1) {
                IO.print((char) i);
            }
            // IOException : 대표적인 checked exception (try ~ catch 문 반드시 사용)
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (fr != null) fr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    /*
    io : input / output stream (lambda stream과 다름!!)
    -> 연속적인 byte 값(배열) 이 전달되는 것을 의미
     */
}
