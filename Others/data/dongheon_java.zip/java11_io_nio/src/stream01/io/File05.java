package stream01.io;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

// file04 복붙해서 수정하기
public class File05 {
    void main() {
        write();
        // writeList();
        read();
    }

    public static void write() {
        // append: true -> 이어쓰기
        try (FileWriter fw = new FileWriter("test04.txt", true)) {
            fw.write("Hello, Java!\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void read() {
        try (FileReader fr = new FileReader("test04.txt")) {
            int i;
            while ((i = fr.read()) != -1) {
                System.out.print((char) i);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void writeList() {
        var messages = List.of("Hello\n", "World\n", "java\n");

        try (FileWriter file = new FileWriter("test04.txt", true)) {
            for (String line : messages) {
                file.write(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}