package method02.other;

import method01.basic.Method;

public class MethodMain {
    void main() {
        Method.publicMethod();
        // MethodHeader.protectedMethod();
        // MethodHeader.defaultMethod();
        Method mt01 = new Method();
        mt01.nonStaticMethod();

    }
}
