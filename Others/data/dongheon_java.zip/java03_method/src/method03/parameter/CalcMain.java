package method03.parameter;

public class CalcMain {
    void main() {

        IO.print("10++ = ");
        // arguments
        Calculator.sum(10);

        IO.println("10 + 3 = " + Calculator.sum(10, 3));
        IO.println("10 - 3 = " + Calculator.sub(10, 3));
        IO.println("10 * 3 = " + Calculator.mul(10, 3));
        IO.println("10 / 3 = " + Calculator.div(10, 3));

    }
}
