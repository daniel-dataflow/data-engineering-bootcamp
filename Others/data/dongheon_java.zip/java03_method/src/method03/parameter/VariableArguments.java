package method03.parameter;

import java.util.Arrays;

public class VariableArguments {
    void main() {
        printName("홍길동");
        printName("홍길동", "이순신");
        printName("홍길동", "이순신", "김선달");
    }

    // variable arguments (VarArgs) : 가변인자 = 배열과 동일
    // String... args == String[] args
    public static void printName(String... args){
        // IO.println(args);
        IO.println(Arrays.toString(args));
    }

}
