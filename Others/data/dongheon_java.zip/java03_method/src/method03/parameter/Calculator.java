package method03.parameter;

public class Calculator {

    // 접근제한자 메모리 리턴타입 메소드명 (파라미터)
    // parameter : method 외부에서 전달되는 값을 받아, method 내부에서 사용하기 위한 "변수"
    // arguments : method 외부에서 전달되는 "값"
    public static int sum(int i) {
        int result = i + 1;

        return result;
    }

    // method overloading : parameter의 갯수 or parameter의 type이 달라야 한다!
    public static int sum(int i, int j) {
        int result = i + j;

        return result;
    }

    public static int sub(int i, int j) {
        int result = i - j;

        return result;
    }

    public static double mul(double i, double j) {
        double result = i * j;

        return result;
    }

    public static String div(int i, int j) {
        int div01 = i / j;
        int div02 = i % j;

        String result = String.format("몫: %d\t나머지: %d", div01, div02);

        return result;
    }


}
