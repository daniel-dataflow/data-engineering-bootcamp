package method01.basic;

public class Method {
    void main() {
        // class.method (static 인 경우)
        Method.publicMethod();
        // 같은 클래스 내에서 호출할 때는 클래스 생략 가능
        protectedMethod();
        defaultMethod();
        privateMethod();

        // class 변수 = new class (non static 인 경우)
        Method method = new Method();
        method.nonStaticMethod();
        IO.println(method.returnTen());
    }

    // 어디서나 접근, 참조 가능 (+)
    public static void publicMethod() {
        IO.println("public method");
    }

    // 같은 패키지 또는 상속받은 클래스 내에서 (#)
    protected static void protectedMethod() {
        IO.println("protected method");
    }

    // 같은 패키지 내에서 (~)
    static void defaultMethod() {
        IO.println("default method");
    }

    // 현재 클래스 내에서 (-)
    private static void privateMethod() {
        IO.println("private method");
    }

    // static이 없음
    public void nonStaticMethod() {
        IO.println("non static method");
    }

    // void : return 할 값이 없음
    public int returnTen() {
        return 10;
    }
}
