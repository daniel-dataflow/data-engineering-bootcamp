package method01.basic;

public class MethodMain {
    void main() {
        Method.publicMethod();
        Method.protectedMethod();
        Method.defaultMethod();

        // MethodHeader.priavateMethod();

        // (intellij idea) MethodHeader 우클릭 -> 다이어그램 -> 다이어그램 표시 -> 오른쪽 위에 f, m, ... 선택
        // UML : Unified Modeling Language
    }
}
