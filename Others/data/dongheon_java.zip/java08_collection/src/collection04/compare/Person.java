package collection04.compare;

public class Person implements Comparable<Person>{
    String name;
    int age;

    public Person(){
        this.name = "hong-gd";
        this.age = 100;
    }
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public int compareTo(Person other){
        return this.age - other.age;
    }

    @Override
    public String toString() {
        return name + " : " + age;
    }
}
