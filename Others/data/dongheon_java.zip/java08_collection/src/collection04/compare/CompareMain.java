package collection04.compare;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class CompareMain {
    void main(){
        var list = new ArrayList<Person>();
        list.add(new Person("홍길동", 100));
        list.add(new Person("이순신", 10));
        list.add(new Person("김선달", 50));

        usingComparable(list);
        usingComporator(list);
    }

    public static void usingComparable(List<Person> list) {
        IO.println(list);
        Collections.sort(list);
        IO.println(list);
    }

    public static void usingComporator(List<Person> list) {
        IO.println(list);

        // 익명 클래스로 바로 객체생성
        list.sort(new Comparator<Person>() {
            @Override
            public int compare(Person o1, Person o2) {
                return o2.age - o1.age;
            }
        });

        IO.println(list);
    }
}
