package collection03.utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class UtilsMain {
    void main() {
        var list = new ArrayList<>(List.of(1, 3, 2, 4, 5));

        IO.println(list);

        Collections.sort(list);
        IO.println(list);

        Collections.reverse(list);
        IO.println(list);

        Collections.shuffle(list);
        IO.println(list);

        IO.println(Collections.max(list));
        IO.println(Collections.min(list));
    }
}
