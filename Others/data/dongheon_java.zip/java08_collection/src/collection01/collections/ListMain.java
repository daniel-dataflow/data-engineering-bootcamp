package collection01.collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class ListMain {
    void main() {
        list01();
        list02();
        list03();
        list04();
        list05();
        list06();
    }

    public static void list01() {
        List<String> list = new ArrayList<>();
        list.add("홍길동");
        list.add("이순신");
        list.add("강호동");
        list.add("유재석");
        list.add("조세호");
        list.add("신동엽");

        IO.println(list);
        list.remove("조세호");
        IO.println(list);
    }

    public static void list02() {
        // List.of : immutable
        List<Integer> binary = List.of(0, 1);
        IO.println(binary);
        // UnsupportedOperationException
        // binary.add(2);
    }

    public static void list03() {
        var list = new ArrayList<String>();
        list.add("홍길동");
        list.add("이순신");
        list.add("강호동");
        list.add("유재석");
        list.add("조세호");
        list.add("신동엽");

        for (int i = 0; i < list.size(); i++) {
            IO.println(list.get(i));
        }
        IO.println();

        for (var i : list) {
            IO.println(i);
        }
        IO.println();

        Iterator<String> iter = list.iterator();
        while(iter.hasNext()) {
            IO.println(iter.next());
        }
    }

    public static void list04() {
        var list = new ArrayList<String>();
        list.add("홍길동");
        list.add("이순신");
        list.add("김선달");

        IO.println(list.contains("이순신"));
        IO.println(list.remove("이순신"));
        IO.println(list);
        list.set(1, "이순신");
        IO.println(list.get(1));
        IO.println(list);
    }

    public static void list05() {
        var list = new ArrayList<String>();
        list.add("홍길동");
        list.add("이순신");
        list.add("김선달");
        list.add("강호동");
        list.add("유재석");
        list.add("조세호");
        list.add("신동엽");

        // ConcurrentModificationException
        /*
        for (String name : list) {
            if (name.equals("조세호")) {
                list.remove(name);
            }
        }
        IO.println(list);
        */

        Iterator<String> iter = list.iterator();
        while(iter.hasNext()) {
            if (iter.next().equals("조세호")) {
                list.remove("조세호");
            }
        }
        IO.println(list);

    }

    public static void list06() {
        /*
        ArrayList : 데이터 조회 에 강력 -> 배열 [] 로 만들어져 있어서 일반적인 상황에선 훨씬 빠름
        LinkedList : 데이터가 수시로 추가 / 삭제 일 때 강력
         */
        LinkedList<Integer> queue = new LinkedList<>();
        queue.add(1);
        queue.add(2);
        queue.addFirst(3);
        queue.addLast(4);
        IO.println(queue);

        queue.set(0, 0);
        queue.set(3, 3);
        IO.println(queue);

        int first = queue.pollFirst();
        IO.println(queue);
        IO.println(first);
        IO.println(queue.getFirst());

        queue.clear();
        IO.println(queue);
    }
}
