package collection01.collections;

import java.util.*;

public class SetMain {
    void main() {
        set01();
        set02();
        set03();
        set04();
        set05();
    }

    public static void set01() {
        Set<String> set = new HashSet<>();
        set.add("홍길동");
        set.add("이순신");
        set.add("김선달");
        set.add("홍길동");
        // 순서 보장 X
        IO.println(set);
        // hashset : hash table에 내부 알고리즘을 통해 data를 저장

        IO.println(set.contains("이순신"));
        IO.println(set.remove("이순신"));
        IO.println(set);
    }

    public static void set02() {
        // collection.of : immutable 객체 생성
        Set<Integer> octal = Set.of(0, 1, 2, 3, 4, 5, 6, 7);
        // octal.add(8);
        IO.println(octal);
    }

    public static void set03() {
        var set = Set.of(3, 2, 1, 5, 4);
        // collection factory로 만들어진 instance 도 hash 알고리즘을 이용
        // 그래서 1, 2, 3, 4, 5 로 정렬된 것 처럼 보이는 것임

        for (int i = 0; i < set.size() ; i++) {
            IO.println(i);
        }

        for (var i : set) {
            IO.println(i);
        }

        var iter = set.iterator();
        while (iter.hasNext()) {
            IO.println(iter.next());
        }
    }

    public static void set04() {
        Set<String> hashSet = new HashSet<>();
        Set<String> linkedSet = new LinkedHashSet<>();
        Set<String> treeSet = new TreeSet<>();

        String[] names = {"홍길동", "이순신", "김선달"};

        for (String name : names) {
            hashSet.add(name);
            linkedSet.add(name);
            treeSet.add(name);
        }

        // 순서 X
        IO.println("HashSet : " + hashSet);
        // 순서 O
        IO.println("LinkedHashSet : " + linkedSet);
        // 정렬 O
        IO.println("TreeSet : " + treeSet);
    }

    public static void set05() {
        // TreeSet은 NavigableSet 인터페이스를 구현함
        TreeSet<Integer> scores = new TreeSet<>();
        scores.addAll(List.of(80, 95, 50, 70, 65));

        // 기본적으로 오륾차순
        IO.println(scores);

        // 1. 특정 점수 근처의 값 찾기
        // 70점보다 낮은
        IO.println(scores.lower(70));
        // 70점보다 높거나 같은 점수
        IO.println(scores.ceiling(70));
        // 90점 바로 위의 점수
        IO.println(scores.higher(90));

        // 2. 가장 높은 점수와 낮은 점수 확인
        IO.println(scores.first());
        IO.println(scores.last());

        // 3. 내림차순 정렬
        NavigableSet<Integer> descendingScores = scores.descendingSet();
        IO.println(descendingScores);

        // 4. 범위 검색 (60점 <= search <= 80)
        IO.println(scores.subSet(60, true, 80, true));
    }
}
