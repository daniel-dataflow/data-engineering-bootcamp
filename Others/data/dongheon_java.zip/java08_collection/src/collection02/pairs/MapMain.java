package collection02.pairs;

import java.util.*;

public class MapMain {
    void main() {
        map01();
        map02();
        map03();
        map04();
    }

    public static void map01() {
        Map<String, Integer> map = new HashMap<>();
        map.put("hong", 100);
        map.put("lee", 95);
        map.put("kim", 85);

        IO.println(map);
        IO.println(map.get("hong"));

        for (var key : map.keySet()) {
            IO.println(key + " : " + map.get(key));
        }
        IO.println();

        // Map.Entry<String, Integer> entry = map.entrySet();
        for (var entry : map.entrySet()) {
            IO.println(entry.getKey() + " : " + entry.getValue());
        }
        IO.println();

        var iter = map.entrySet().iterator();
        while(iter.hasNext()) {
            var entry = iter.next();
            IO.println(entry.getKey() + " : " + entry.getValue());
        }
    }

    public static void map02() {
        var map = Map.of("hong",100, "lee",95, "kim", 85);

        IO.println(map.containsKey("hong"));
        IO.println(map.containsValue(90));

        // 삭제된 key.value 의 value가 리턴
        IO.println(map.remove("lee"));
        IO.println(map);
    }

    public static void map03() {
        var hashMap = new HashMap<>();
        var linkedMap = new LinkedHashMap<>();
        var treeMap = new TreeMap<>();

        String[] keys = {"C", "A", "B", "D"};

        for (String key : keys) {
            hashMap.put(key, key.charAt(0) - 64);
            linkedMap.put(key, key.charAt(0) - 64);
            treeMap.put(key, key.charAt(0) - 64);
        }

        IO.println("HashMap : " + hashMap);
        IO.println("LinkedHashMap: " + linkedMap);
        IO.println("TreeMap : " + treeMap);
    }

    public static void map04() {
        // TreeMap은 NavigableMap 인터페이스를 구현함
        TreeMap<Integer, String> scores = new TreeMap<>();

        scores.put(50, "F");
        scores.put(65, "D");
        scores.put(70, "C");
        scores.put(80, "B");
        scores.put(95, "A");

        // 기본적으로 key 기준 오름차순
        IO.println(scores);

        // 특정 key 근처의 entry 찾기
        // 70점보다 낮은 점수
        IO.println(scores.lowerEntry(70));

        // 70점보다 높거나 같은 점수
        IO.println(scores.ceilingEntry(70));

        // 90점 초과 중 가장 가까운 점수
        IO.println(scores.higherEntry(90));

        // 가장 낮은 / 높은 entry
        IO.println(scores.firstEntry());
        IO.println(scores.lastEntry());

        // 내림차순 정렬
        NavigableMap<Integer, String> descendingScores = scores.descendingMap();
        IO.println(descendingScores);

        // 범위 검색 (60 <= key <= 80)
        IO.println(scores.subMap(60, true, 80, true));

        // key만 필요할 때
        IO.println(scores.navigableKeySet());
    }
}
