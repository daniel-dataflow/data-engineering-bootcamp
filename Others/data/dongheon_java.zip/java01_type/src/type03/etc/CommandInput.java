package type03.etc;

import java.util.Scanner;

public class CommandInput {
    void main() {
        // 내부적으로 System.in 사용
        String inputIO = IO.readln();
        IO.println(inputIO);

        Scanner sc = new Scanner(System.in);
        String inputSystem = sc.nextLine();
        IO.println(inputSystem);
    }
}
