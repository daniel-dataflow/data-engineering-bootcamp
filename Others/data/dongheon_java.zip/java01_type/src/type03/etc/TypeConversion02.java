package type03.etc;

public class TypeConversion02 {
    void main() {
        // boxing (명시적)
        int a = 100;
        Integer boxedA = Integer.valueOf(a);  // int -> Integer 명시적 변환
        System.out.println("Boxing: " + boxedA);

        // auto-boxing (묵시적)
        int b = 100;
        Integer autoBoxedB = b;
        System.out.println("Auto-boxing: " + autoBoxedB);

        // unboxing (명시적)
        Integer c = Integer.valueOf(200);
        int unboxedC = c.intValue();
        System.out.println("Unboxing: " + unboxedC);

        // auto-unboxing (묵시적)
        Integer d = Integer.valueOf(200);
        int autoUnboxedD = d;
        System.out.println("Auto-unboxing: " + autoUnboxedD);
    }
}
