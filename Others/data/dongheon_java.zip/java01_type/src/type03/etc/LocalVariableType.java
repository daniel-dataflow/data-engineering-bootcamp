package type03.etc;

public class LocalVariableType {
    void main() {
        /*
        var : 지역 변수 타입 추론(Local Variable Type Inference)
        - compile 시 값의 type을 추론 -> 이후에 다른 type으로 변환 불가
        - 지역변수에서만 사용 가능
        - 반드시 초기화 필요 (선언으로 끝나면 안됨)
        - null 로 초기화 불가
         */
        var i = Integer.valueOf(0);
        IO.println(i);
        i = null;
        IO.println(i);

        var j = 0;
        IO.println(j);
        // j = null;

    }
}
