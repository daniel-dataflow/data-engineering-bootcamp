package type03.etc;

public class TypeConversion01 {
    void main() {
        // 묵시적 형변환 : 작은 타입에서 큰 타입으로 - promotion (참조타입은 upCasting)
        byte b01 = (byte) 100;
        int i01 = b01;
        IO.println(i01);

        // 명시적 형변환 : 큰 타입에서 작은 타입으로 - casting (참조타입은 downCasting)
        int i02 = 100;
        byte b2 = (byte)i02;
        IO.println(b2);
    }
}
