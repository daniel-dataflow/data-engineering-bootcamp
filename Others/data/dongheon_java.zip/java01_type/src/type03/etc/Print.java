package type03.etc;

public class Print {
    void main() {
        /*
        print : 줄 바꿈 없음
        println : 줄 바꿈 포함
        f : formatter (자리 or 형식) -> java.base / java.util.Formatter

        java.base / java.lang.System -> System.out.println
        java.base / java.lang.IO -> IO.println : 25 에서 나온 축약형태 (내부적으로는 System.out.println 호출)
        -> PrintStream method
         */

        String name = "dongheon";
        int age = 100;

        System.out.print("1. name : " + name + "\n");
        System.out.println("2. age : " + age);
        System.out.printf("3. format : _%10d_%5d\n", age, age);

        double pi = 3.141592;
        String formatString = String.format("My name is %s. \nPI = %.2f", name, pi);
        IO.println(formatString);

    }
}
