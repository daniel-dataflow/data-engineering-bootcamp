package type02.reference;

public class Type02_Wrapper {
    void main() {
        /*
        primitive       ->      wrapper

        byte                    Byte
        short                   Short
        int                     Integer
        long                    Long
        float                   Float
        double                  Double
        char                    Character
        boolean                 Boolean
         */

        IO.println(Byte.MIN_VALUE + " ~ " + Byte.MAX_VALUE);
        IO.println(Short.MIN_VALUE + " ~ " + Short.MAX_VALUE);
        IO.println(Integer.MIN_VALUE + " ~ " + Integer.MAX_VALUE);
        IO.println(Long.MIN_VALUE + " ~ " + Long.MAX_VALUE);
        IO.println(Character.MIN_VALUE + " ~ " + Character.MAX_VALUE);
        IO.println((int)Character.MIN_VALUE + " ~ " + (int)Character.MAX_VALUE);

        IO.println(Float.MIN_VALUE + " ~ " + Float.MAX_VALUE);
        IO.println(Double.MIN_VALUE + " ~ " + Double.MAX_VALUE);

        IO.println(Boolean.valueOf("true"));
    }
}
