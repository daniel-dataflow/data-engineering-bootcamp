package type02.reference;

public class Type01_String {
    void main() {
        // String : 참조타입이지만 기본타입처럼 사용
        String s01 = "aaa";
        String s02 = "bb";
        String concat = s01 + s02;
        IO.println(concat);

        // 참조타입 (class) 는 기능을 사용할 수 있다.
        IO.println(concat.toUpperCase());

    }
}
