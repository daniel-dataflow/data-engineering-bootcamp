package type02.reference;

public class Type03_Person {
    void main() {
        // 참조타입 변수 = new 참조타입();
        // new -> constructor 호출
        Person dongheon = new Person();
        IO.println(dongheon);
        IO.println(dongheon.name);
        IO.println(dongheon.age);
    }
}
