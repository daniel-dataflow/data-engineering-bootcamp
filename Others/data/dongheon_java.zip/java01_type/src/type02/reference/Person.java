package type02.reference;

public class Person {
    int age = 100;
    String name = "dongheon";
}
