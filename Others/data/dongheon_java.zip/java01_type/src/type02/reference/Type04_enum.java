package type02.reference;

public class Type04_enum {
    void main() {
        // enum : 열거형 class (상수들의 집합을 정의)
        enum Day { SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY }

        IO.println(Day.SUNDAY);
    }
}
