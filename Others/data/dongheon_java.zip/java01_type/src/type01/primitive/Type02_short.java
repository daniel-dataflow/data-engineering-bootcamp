package type01.primitive;

public class Type02_short {

    // public static void main(String[] args) -> void main()
    void main() {
        // For short, from -32768 to 32767
        short s01 = 32767;
        IO.println(s01);

        short s02 = 1;
        IO.println(s02);

        short sum = (short)(s01 + s02);
        IO.println(sum);
    }
}
