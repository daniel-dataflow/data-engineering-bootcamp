package type01.primitive;

public class Type01_byte {

    // literal : 값 자체를 의미

    /*
    PrimitiveType
        NumericType
            IntegralType : byte(1byte), short(2byte), int(4byte), long(8byte), char(2byte)
            FloatingPointType : float(4byte), double(8byte)
        boolean(1byte)
     */

    public static void main(String[] args) {
        // type variable = literal
        byte b01 = 127;
        IO.println(b01);

        // For byte, from -128 to 127
        // 정수값의 기본 type은 int -> 형변환
        byte b02 = (byte) 128;
        IO.println(b02);

        // 연산 결과의 기본 type 도 int
        byte sum = (byte)(b01 + 1);
        IO.println(sum);

    }
}
