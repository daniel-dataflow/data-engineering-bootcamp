package type01.primitive;

public class Type05_char {
    void main() {
        // For char, from '\u0000' to '\uffff' inclusive, that is, from 0 to 65535
        char c01 = 'a';
        IO.println(c01);
        char c02 = 'A';
        IO.println(c02);
        int c01ToInt = (int)c01;
        IO.println(c01ToInt);

        // ascii code 표 검색!
    }
}
