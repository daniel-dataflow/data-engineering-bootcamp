package type01.primitive;

public class Type08_boolean {
    void main() {
        // boolean (1byte)
        // 논리값 (true, false) 저장
        // 1bit (0 또는 1) 로 표현 가능한데 왜 1byte? -> java에서 데이터를 처리하기 위한 최소 단위를 1byte로 지정
        boolean t = true;
        boolean f = false;
        IO.println(t);
        IO.println(f);

    }
}
