package type01.primitive;

public class Type06_float {
    void main() {
        // 정수형 타입의 기본은 int. 실수형 타입의 기본은 double
        // float (4byte)
        // 접미사 f, F
        float f01 = 0.1f;
        float f02 = 9.9F;
        float sum = f01 + f02;
        IO.println(sum);
    }
}
