package type01.primitive;

public class Type07_double {
    void main() {
        // 실수의 기본이 double 이기 때문에 접미사 생략 가능
        // double (8byte)
        // 접미사 d,D
        double d01 = 100.04;
        double d02 = 100.06;
        double sum = d01 + d02;
        IO.println(sum);
    }
}
