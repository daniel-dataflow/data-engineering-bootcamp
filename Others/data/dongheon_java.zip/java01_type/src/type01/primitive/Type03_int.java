package type01.primitive;

public class Type03_int {
    void main() {
        // For int, from -2147483648 to 2147483647
        int i = 10;
        int j = 20;
        int sum = i + j;
        IO.println(i + " + " + j + " = " + sum);

        // binary(2) octal(8) hexadecimal(16)
        // 0b : 2진수
        IO.println(0b10);
        // 00 : 8진수
        IO.println(0010);
        // 0x : 16진수
        IO.println(0x10);

        /*
        fortran 에서는 i ~ n 까지의 변수를 정수로 취급 -> 관습적으로 사용
        물리 / 수학에서는 iterator, index 등의 뜻으로 i 사용
         */
    }
}
