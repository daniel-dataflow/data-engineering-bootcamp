package type01.primitive;

public class Type04_long {
    void main() {
        // For long, from -9223372036854775808 to 9223372036854775807
        // 접미사 l, L
        // 30억, 40억
        long l01 = 3000000000l;
        long l02 = 4000000000L;
        long sum = l01 + l02;
        IO.println(sum);
    }
}
