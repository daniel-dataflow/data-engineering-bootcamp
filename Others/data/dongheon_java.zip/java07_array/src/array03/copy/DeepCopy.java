package array03.copy;

import java.util.Arrays;

public class DeepCopy {
    void main() {
        Person[] original = {new Person("hong-gd", 10), new Person("kim-sd", 20)};
        Person[] copy = new Person[original.length];
        for (int i=0; i < copy.length; i++) {
            copy[i] = new Person(original[i].name, original[i].age);
        }

        IO.println(Arrays.toString(original));
        IO.println(Arrays.toString(copy));
        // 배열도 다르고
        IO.println(original == copy);
        // 배열 안의 값도 다르고
        IO.println(original[0] == copy[0]);
        copy[0].age = 100;
        IO.println(Arrays.toString(original));
        IO.println(Arrays.toString(copy));

    }
}
