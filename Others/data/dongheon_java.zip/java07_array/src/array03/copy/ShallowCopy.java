package array03.copy;

import java.util.Arrays;

public class ShallowCopy {
    void main() {
        Person[] original = {new Person("hong-gd", 10), new Person("kim-sd", 20)};
        Person[] copy = original.clone();

        IO.println(Arrays.toString(original));
        IO.println(Arrays.toString(copy));
        // 배열은 다른데
        IO.println(original == copy);
        // 배열 안의 값은 같다.
        IO.println(original[0] == copy[0]);
        copy[0].age = 100;
        IO.println(Arrays.toString(original));
        IO.println(Arrays.toString(copy));
    }
}
