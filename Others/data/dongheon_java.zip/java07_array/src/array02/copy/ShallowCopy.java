package array02.copy;

import java.util.Arrays;

public class ShallowCopy {
    void main() {
        int[] original = {10, 20, 30};
        int[] copy = original;

        IO.println(Arrays.toString(original));
        IO.println(Arrays.toString(copy));
        copy[0] = 100;
        IO.println(Arrays.toString(original));
        IO.println(Arrays.toString(copy));

        IO.println(original.hashCode());
        IO.println(copy.hashCode());

        IO.println(System.identityHashCode(original));
        IO.println(System.identityHashCode(copy));
    }
}
