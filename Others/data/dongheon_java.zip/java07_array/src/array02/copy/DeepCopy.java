package array02.copy;

import java.util.Arrays;

public class DeepCopy {
    void main() {
        int[] original = {10, 20, 30, 40, 50};

        // 방법 1
        int[] copy01 = new int [original.length];
        for (int i = 0; i < original.length ; i++) {
            copy01[i] = original[i];
        }
        IO.println(Arrays.toString(original));
        IO.println(Arrays.toString(copy01));
        copy01[0] = 100;
        IO.println(Arrays.toString(original));
        IO.println(Arrays.toString(copy01));

        // 방법 2
        int[] copy02 = original.clone();
        IO.println(Arrays.toString(original));
        IO.println(Arrays.toString(copy02));
        copy02[1] = 200;
        IO.println(Arrays.toString(original));
        IO.println(Arrays.toString(copy02));

        // 방법 3
        int[] copy03 = Arrays.copyOf(original, original.length);
        IO.println(Arrays.toString(original));
        IO.println(Arrays.toString(copy03));
        copy03[2] = 300;
        IO.println(Arrays.toString(original));
        IO.println(Arrays.toString(copy03));


        // 방법 4
        int[] copy04 = new int[original.length];
        Arrays.fill(copy04, 500);
        // System.arrayCopy(원본 배열, 원본 시작 idx, 복사 배열, 복사 시작 idx, 복사 갯수)
        System.arraycopy(original, 0, copy04, 1, 2);
        IO.println(Arrays.toString(copy04));

        IO.println(System.identityHashCode(original));
        IO.println(System.identityHashCode(copy01));
        IO.println(System.identityHashCode(copy02));
        IO.println(System.identityHashCode(copy03));
        IO.println(System.identityHashCode(copy04));
    }
}
