package array01.basic;

import java.util.Arrays;

public class OneDimensionArray {
    void main() {
        array01();
        array02();
        array03();
        array04();
        array05();
    }

    public static void array01() {
        int a = 1;
        int b = 2;
        int c = 3;
        int d = 4;
        int e = 5;
        int f = 6;
        int g = 7;
        int h = 8;
        int i = 9;
        int j = 10;

        IO.println(a);
        IO.println(b);
        // ...
    }

    public static void array02() {
        // array : 같은 type의 여러 개의 값을 효과적으로 관리하기 위한 객체
        int [] num;
        // 초기화 시 입력한 크기가 고정! (변경 불가)
        num = new int[5];
        // index로 참조 (0부터 시작)
        num[0] = 1;
        num[1] = 2;
        num[2] = 3;
        num[3] = 4;
        num[4] = 5;
        IO.println(num);
        IO.println(num.length);
        for (int i = 0; i < num.length ; i++) {
            IO.println(i);
        }
    }

    public static void array03() {
        int[] num = new int[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        // inhanced for (향상된 for) -> foreach 라고도 불렀었는데, stream 에서 forEach가 나와서 헷갈림 주의!
        for (int i : num) {
            IO.println(i);
        }
    }

    public static void array04() {
        int[] num = new int[] {1, 3, 2, 7, 9, 8, 10, 5, 4, 6};
        IO.println(Arrays.toString(num));

        Arrays.sort(num);
        IO.println(Arrays.toString(num));

        num = new int[] {1, 3, 2, 7, 9, 8, 10, 5, 4, 6};
        // key (item) 이 몇 번째 index에 있는지 검색
        IO.println(Arrays.binarySearch(num, 9));

        String[] str = new String[10];
        // index 에 값을 입력해주지 않으면 기본값으로 채움
        IO.println(Arrays.toString(str));
        Arrays.fill(str, "na");
        IO.println(Arrays.toString(str));
    }

    public static void array05() {
        Person[] people = new Person[3];
        people[0] = new Person("hong-gd", 100);
        people[1] = new Person("lee-ss", 50);
        people[2] = new Person("kim-sd", 70);

        for (Person person : people) {
            IO.println(person);
        }
    }
}
