package array01.basic;

import java.util.Arrays;

public class MultiDimensionArray {
    void main() {
        array01();
        array02();
    }

    public static void array01() {
        // 2개의 값(배열) 이 들어갈 수 있는 배열에 / 3개의 값(배열) 이 들어갈거야
        int[][] matrix = new int [2][3];

        matrix[0][0] = 1;
        matrix[0][1] = 2;
        matrix[0][2] = 3;
        matrix[1][0] = 4;
        matrix[1][1] = 5;
        matrix[1][2] = 6;

        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                IO.print(matrix[i][j] + " ");
            }
            IO.println();
        }

        IO.println(Arrays.toString(matrix));
        IO.println(Arrays.deepToString(matrix));
    }

    public static void array02() {
        // 3개의 값(배열) 을 가질 수 있는 배열 / 안에도 다시 값(배열)
        String[][] fruits = new String[3][];
        fruits[0] = new String[2];
        fruits[1] = new String[1];
        fruits[2] = new String[3];

        fruits[0][0] = "banana";
        fruits[0][1] = "strawberry";

        fruits[1][0] = "watermelon";

        fruits[2][0] = "orange";
        fruits[2][1] = "grape";
        fruits[2][2] = "apple";

        IO.println(Arrays.deepToString(fruits));
        for (int i = 0; i < fruits.length; i++) {
            for (int j = 0; j < fruits[i].length; j++) {
                IO.print(fruits[i][j] + " ");
            }
            IO.println();
        }
    }
}
