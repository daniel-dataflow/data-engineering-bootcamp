package hello;

public class Hello {
    static void main() {
        System.out.println("Hello, World!");
        // IO.println : 25 버전부터 추가
        IO.println("Hello, Java!");

        // 한 줄 주석
        /*
        여러 줄 주석
        주석 = 사람에게 보여주기 위한 설명
        compile 시점에 주석은 제거됨

        package : 서로 관련있는 클래스들의 모음 (=폴더, 디렉토리)
         */
    }
}
