package statements03.block;

public class CodeBlock {
    void main() {
        blockScope();
        block01(10, 3);
        block02();
    }

    public static void blockScope() {
        {
            int i = 10;
            IO.println(i);
        }

        // block 외부에서 접근 불가
        // IO.println(i);
    }

    public static void block01(int i, int j) {
        {
            int result = i + j;
            IO.println(result);
        }

        {
            int result = i - j;
            IO.println(result);
        }

        // named block
        mul: {
            int result = i * j;
            IO.println(result);
        }
    }

    public static void block02() {
        int i = 0;
        outer: {
            IO.println("블록 시작");

            while (true) {
                IO.println(i++);
                if (i == 10) {
                    // 단슨 break로는 while만 종료
                    // break;

                    // outer block 전체 종료 (그래서 "블록 끝" 이 출력되지 않음)
                    break outer;
                }
            }
            // outer가 종료되기 때문에 해당 명령어 실행 불가
            // IO.println("블록 끝");
        }

        IO.println("블록 종료 후 실행");
    }

}

