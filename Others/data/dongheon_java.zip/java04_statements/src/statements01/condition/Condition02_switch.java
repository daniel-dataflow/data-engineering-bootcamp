package statements01.condition;

public class Condition02_switch {
    void main() {
        switch01();
        switch02();
        switch03();
        switch04();
        IO.println(switch05(0));
        IO.println(switch06(6));
        IO.println(switch07());
    }

    public static void switch01() {
        // if는 순차적으로 모든 코드를 읽어드리지만
        // switch는 case 값이 상수이면 jump table 생성 (빠르게 분기 가능)
        // fall through : break가 없으면 다음 case로 계속 진행
        int i = 3;
        switch(i) {
            case 1:
                IO.println("1 입니다.");
            case 2:
                IO.println("2 입니다.");
            case 3:
                IO.println("3 입니다.");
            case 4:
                IO.println("4 입니다.");
            case 5:
                IO.println("5 입니다.");
        }
    }

    public static void switch02() {
        int i = 3;
        switch(i) {
            case 1:
                IO.println("1 입니다.");
                // break : 현재 block을 종료해라.
                break;
            case 2:
                IO.println("2 입니다.");
                break;
            case 3:
                IO.println("3 입니다.");
                break;
            case 4:
                IO.println("4 입니다.");
                break;
            case 5:
                IO.println("5 입니다.");
                break;
        }
    }

    public static void switch03() {
        int i = 3;
        switch(i) {
            case 1:
            case 3:
                IO.println("홀수 입니다.");
                break;
            case 2:
            case 4:
                IO.println("짝수 입니다.");
                break;
            default:
                IO.println("1 ~ 4 사이의 수만 입력해주세요.");
        }
    }

    public static void switch04() {
        int i = 3;
        switch(i) {
            case 1, 3:
                IO.println("홀수 입니다.");
                break;
            case 2, 4:
                IO.println("짝수 입니다.");
                break;
            default:
                IO.println("1 ~ 4 사이의 수만 입력해주세요.");
        }
    }

    public static String switch05(int day) {
        // case return (switch 가 statements가 아닌 expression이 됨 -> 반드시 모든 case, default 필요)
        // case마다 실행할 식 (expression) 바로 연결 (lambda expression -> interface 이후에 다시 배움)
        return switch(day) {
            case 0 -> "sunday";
            case 1 -> "monday";
            case 2 -> "tuesday";
            case 3 -> "wednesday";
            case 4 -> "thursday";
            case 5 -> "friday";
            case 6 -> "saturday";
            default -> "invalid day";
        };

    }

    public static String switch06(int day) {
        // yield : block 안에서 expression 리턴
        // yield로 반환하는 값은 모든 case가 반드시 같은 타입
        // lambda식 (->) 은 한줄만 가능. yield는 여러 줄 가능
        return switch (day) {
            case 0, 6: {
                boolean isHoliday = true;
                String info = (day == 0 ? "sunday": "saturday");
                yield info + (isHoliday ? " (Holiday)" : "");
            }
            case 1, 2, 3, 4, 5 : {
                boolean isHoliday = false;
                String info = switch (day) {
                    case 1 -> "monday";
                    case 2 -> "tuesday";
                    case 3 -> "wednesday";
                    case 4 -> "thursday";
                    case 5 -> "friday";
                    default -> "invalid";
                };
                yield info + (isHoliday ? "(holiday)" : "");
            }
            default : {
                yield "Invalid day";
            }
        };
    }

    public static String switch07() {
        enum Day { SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY }

        Day day = Day.FRIDAY;
        String result = switch(day) {
            case SUNDAY -> "sunday";
            case MONDAY -> "monday";
            case TUESDAY -> "tuesday";
            case WEDNESDAY -> "wednesday";
            case THURSDAY -> "thursday";
            case FRIDAY -> "friday";
            case SATURDAY -> "saturday";
        };

        return result;
    }
}
