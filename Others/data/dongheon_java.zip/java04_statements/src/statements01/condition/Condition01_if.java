package statements01.condition;

public class Condition01_if {
    void main() {
        int i = 10;
        int j = 3;
        if01(i, j);
        if02(i, j);
        if03(i, j);
        if04(i, j);
        if05(i, j);
    }

    public static void if01(int i, int j) {
        if (i > j) {
            IO.println("i 가 j 보다 크다.");
        }
    }

    public static void if02(int i, int j) {
        if (i > j) {
            IO.println("i 가 j 보다 크다.");
        } else if (i < j) {
            IO.println("i 가 j 보다 작다.");
        } else if (i == j) {
            IO.println("i 가 j 와 같다.");
        } else if (i != j) {
            IO.println("i 가 j 와 다르다.");
        }
    }

    public static void if03(int i, int j) {
        if (i > j) {
            IO.println("i 가 j 보다 크다.");
        } else if (i < j) {
            IO.println("i 가 j 보다 작다.");
        } else {
            IO.println("i 가 j 와 같다.");
        }
    }

    public static void if04(int i, int j) {
        if (i > j) {
            IO.println("i 가 j 보다 크다.");
        }

        if (i < j) {
            IO.println("i 가 j 보다 작다.");
        }

        if (i == j) {
            IO.println("i 가 j 와 같다.");
        }

        if (i != j) {
            IO.println("i 가 j 와 다르다.");
        }
    }

    public static void if05(int i, int j) {
        if (i >= j) {
            if (i == j) {
                IO.println("i 와 j 가 같다");
            } else {
                IO.println("i 가 j 보다 크다");
            }
        } else {
            IO.println("i 가 j 보다 작다");
        }
    }

}
