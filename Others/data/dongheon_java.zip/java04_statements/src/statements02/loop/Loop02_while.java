package statements02.loop;

public class Loop02_while {
    void main() {
        while01();
        while02();
        while03();
    }

    public static void while01() {
        int i = 1;

        while(i < 10) {
            IO.println(i);
            i++;
        }

        IO.println("while이 종료된 후의 i 값 : " + i);
    }

    public static void while02() {
        int i = 1;

        do {
            IO.println(i);
            i++;
        }while(i < 10);
        //i == 10 이면 안되는 이유! false라서

        IO.println("do while이 종료된 후의 i 값 : " + i);
    }

    public static void while03() {
        int i = 10;

        // 실행 안됨
        while (i < 10) {
            IO.println(i);
        }

        // 한 번은 실행됨
        do {
            IO.println(i);
        } while (i < 10);
    }
}
