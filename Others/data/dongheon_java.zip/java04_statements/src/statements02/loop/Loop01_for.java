package statements02.loop;

public class Loop01_for {
    void main() {
        for01();
        for02();
        for03();
        for04();
    }

    public static void for01() {
        // for (초기값 ; 조건식 ; 증감식)
        for (int i = 0; i < 10; i++) {
            IO.println(i);
        }

        // for block 안에서만 사용 가능
        // IO.println(i);
    }

    public static void for02() {
        for(int i = 100; i >= 1; i--) {

            if(i % 10 == 0) {
                IO.println();
            }

            IO.print(String.format("%3d", i));
        }
        IO.println();
    }

    public static void for03() {
        for (int i = 0 ; i < 10; i++) {
            if (i % 2 == 0) {
                // continue : 현재 블록의 다음 명령어는 건너띔
               continue;
            }
            // 홀수만 출력
            IO.println(i);
        }
    }

    public static void for04() {
        for(int i = 0 ; i < 10; i++) {
            for(int j = 0 ; j < 10; j++) {
                // break point 잡아서 debug 하기
                IO.println("i = " + i + " j = " + j);
            }
            IO.println();
        }
    }
}
