package class04.inheritance;

public class Person {
    String name;
    int age;

    Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public boolean equals(Object obj){
        if (this == obj) {
            return true;
        } else {
            Person other = (Person) obj;
            if (this.name.equals(other.name) && this.age == other.age ) {
                return true;
            } else {
                return false;
            }
        }
    }

    @Override
    public String toString() {
        return "name : " + name + "\t age : " + age;
    }
}
