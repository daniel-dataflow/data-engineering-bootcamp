package class04.inheritance;

public class PersonMain {
    void main() {
        Person hong01 = new Person("hong-gd", 100);
        Person hong02 = new Person("hong-gd", 100);

        IO.println(hong01);
        IO.println(hong02);
        IO.println(hong01.equals(hong02));
    }
}
