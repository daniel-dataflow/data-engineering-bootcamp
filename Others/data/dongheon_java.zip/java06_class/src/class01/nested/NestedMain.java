package class01.nested;

public class NestedMain {
    void main() {
        TopLevelClass.StaticClass.print();

        TopLevelClass topLevelInstance = new TopLevelClass();
        TopLevelClass.InnerClass innerInstance = topLevelInstance.new InnerClass();
        innerInstance.print();
        // class.innerclass.print 가능 (print가 static이라서)
        TopLevelClass.InnerClass.print();

        TopLevelClass.localClass();
        topLevelInstance.anonymous.run();
    }
}
