package class01.nested;

// top level class : class 이름이 .java file 이름 (public, default 가능)
public class TopLevelClass {
    // nested class : class 혹은 interface 내부에 선언된 class

    // static nested class : 외부 클래스의 인스턴스가 없어도 생성 가능 (= static memer class)
    static class StaticClass {
        public static void print(){
            IO.println("static class");
        }
    }

    // inner class : top level classs의 내부에 있는 non-static class (= instanace member class, local class, anonymouse class)
    class InnerClass {
        public static void print(){
            IO.println("inner class");
        }
    }

    public static void localClass(){
        // local class : method 내부에서 선언
        class LocalClass {
            public static void print(){
                IO.println("local class");
            }
        }

        LocalClass.print();
    }

    // anonymous class : 이름이 없는 class (interface를 일회성으로 구현하고 싶을 때 사용)
    Runnable anonymous = new Runnable() {
        @Override
        public void run() {
            System.out.println("anonymous Class");
        }
    };

}
