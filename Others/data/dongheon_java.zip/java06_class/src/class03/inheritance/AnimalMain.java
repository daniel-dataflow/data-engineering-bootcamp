package class03.inheritance;

public class AnimalMain {
    void main() {
        Animal animal01 = new Tiger();
        Animal animal02 = new Lion();
        Animal animal03 = new Rabbit();
        Animal animal04 = new Herbivore();

        sealedTypeSwitch(animal01);
        sealedTypeSwitch(animal02);
        sealedTypeSwitch(animal03);
        sealedTypeSwitch(animal04);
    }

    // pattern matching : type에 맞게 변수 binding
    public static void sealedTypeSwitch(Animal animal) {
        // Animal type은 Carnivore 와 Herbivore 만 가질 수 있으므로 default가 필요 없음
        switch (animal) {
            case Carnivore carnivore -> carnivore.eat();
            case Herbivore herbivore -> herbivore.eat();

        }
    }}