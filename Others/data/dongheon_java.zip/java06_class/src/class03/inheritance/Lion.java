package class03.inheritance;

public final class Lion extends Carnivore{
    @Override
    public void eat() {
        IO.print("사자가 ");
        super.eat();
    }
}
