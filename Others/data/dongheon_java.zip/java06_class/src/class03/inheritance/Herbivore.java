package class03.inheritance;

// non-sealed : 상속 제한 해제
public non-sealed class Herbivore extends Animal{
    @Override
    public void eat() {
        IO.println("샐러드를 냠냠");
    }
}
