package class03.inheritance;

// sealed class를 상속받으면, sealed, non-sealed, final keyword 를 반드시 작성!
// sealed : 상속 제한 계속 / non-seale : 상속 제한 해제 / final : 손자 class 제한
public sealed class Carnivore extends Animal permits Tiger, Lion{
    @Override
    public void eat() {
        IO.println("고기를 냠냠");
    }
}
