package class03.inheritance;

public class Rabbit extends Herbivore{
    @Override
    public void eat() {
        IO.print("토끼가 ");
        super.eat();
    }
}
