package class03.inheritance;

public final class Tiger extends Carnivore{
    @Override
    public void eat() {
        IO.print("호랑이가 ");
        super.eat();
    }
}
