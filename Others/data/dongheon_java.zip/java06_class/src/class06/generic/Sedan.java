package class06.generic;

public record Sedan(CarInfo info, boolean hasSunroof) implements Car{
}
