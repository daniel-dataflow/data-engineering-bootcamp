package class06.generic;

public class Garage02<T> {
    private T car;

    public void parking(T car) {
        this.car = car;
    }

    public T getCar() {
        return this.car;
    }
}
