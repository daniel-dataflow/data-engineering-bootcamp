package class06.generic;

public class Garage01 {
    private Object car;

    public void parking(Object car) {
        this.car = car;
    }

    public Object getCar() {
        return this.car;
    }
}
