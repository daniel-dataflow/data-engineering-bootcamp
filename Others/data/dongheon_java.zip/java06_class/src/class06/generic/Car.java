package class06.generic;

public sealed interface Car permits Sedan, Truck{
}
