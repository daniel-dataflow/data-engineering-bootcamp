package class06.generic;

public record Truck(CarInfo info, int capacity) implements Car{
}
