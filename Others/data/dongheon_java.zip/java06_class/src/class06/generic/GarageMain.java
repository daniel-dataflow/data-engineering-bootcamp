package class06.generic;

public class GarageMain {
    void main() {
        Sedan dream = new Sedan(new CarInfo("롤스로이스", "12가 3456"), true);

        Garage01 oldGarage = new Garage01();
        oldGarage.parking(dream);

        // downCasting
        Sedan car01 = (Sedan) oldGarage.getCar();
        IO.println(car01.info().model());

        // 잘못된 값이 입력되도 compile 시 check 불가
        oldGarage.parking("자전거");

        Garage02<Sedan> sedanGarage = new Garage02<>();
        sedanGarage.parking(dream);

        // casting 생략
        Sedan car02 = sedanGarage.getCar();
        IO.println(car02.info().model());

        /*
        generic 관용적 표현
        <T> : type
        <E> : Element
        <K, V> : Key, Value
         */
    }
}
