package class06.generic;

public record CarInfo(String model, String numer) {
}
