package class05.pattern;

public class AnimalMain {
    void main() {
        Animal dog = new Dog(new AnimalInfo("멍멍이", 3), 3);
        Animal cat = new Cat(new AnimalInfo("냐옹이", 2), true);
        Object str = "동물이 아닙니다.";

        usingInstanceOf(dog);
        usingInstanceOf(cat);
        usingInstanceOf(str);

        usingSwitchPattern(dog);
        usingSwitchPattern(cat);

        usingRecordDeconstruction(dog);
        usingRecordDeconstruction(cat);
        /*
        Pattern matching
        - instanceof : casting 생략
        - switch : sealed 를 사용하여 default 생략
        - record : record 객체의 data를 deconstruction (구조 분해)
         */
    }

    public static void usingInstanceOf(Object object) {
        // type 확인과 동시에 animal 변수 사용 (casting 생략)
        if (object instanceof Animal animal) {
            IO.println(animal);
        } else {
            IO.println("강아지나 고양이가 아닙니다.");
        }
    }

    public static void usingSwitchPattern(Animal animal) {
        // Animal이 sealed이므로 모든 자식(Dog, Cat)을 다루면 default가 필요 없음
        switch (animal) {
            case Dog dog -> IO.println("강아지 진료 중: " + dog.info().name());
            case Cat cat -> IO.println("고양이 진료 중: " + cat.info().name());
        }
    }

    public static void usingRecordDeconstruction(Animal animal) {
        switch (animal) {
            // record 구조를 분해해서 변수로
            case Dog(AnimalInfo(String name, int age), int count) ->
                    IO.println("이름: " + name + "\t 나이: " + age + "\t 산책횟수: " + count);

            case Cat(AnimalInfo(String name, int age), boolean scary) ->
                    IO.println("이름: " + name + "\t 나이: " + age + "\t 낮잠확인: " + scary);
        }
    }
}
