package class05.pattern;

public record Dog(AnimalInfo info, int walkingCount) implements Animal {
}