package class05.pattern;

public record Cat(AnimalInfo info, boolean isSleep) implements Animal {
}
