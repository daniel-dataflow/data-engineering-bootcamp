package class05.pattern;

public sealed interface Animal permits Dog, Cat{
}
