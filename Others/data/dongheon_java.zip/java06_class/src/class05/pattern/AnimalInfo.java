package class05.pattern;

public record AnimalInfo(String name, int age) {
}
