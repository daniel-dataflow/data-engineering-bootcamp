package class07.mutable;

public class Mutable01 {
    void main() {
        immutable();
        mutable();
    }

    public static void immutable() {
        String str01 = "java";
        IO.println(str01);
        IO.println(System.identityHashCode(str01));

        String str02 = str01 + "!!";
        IO.println(str02);
        IO.println(System.identityHashCode(str02));

    }

    public static void mutable() {
        StringBuilder sb01 = new StringBuilder("java");
        IO.println(sb01);
        IO.println(System.identityHashCode(sb01));

        sb01.append("!!");
        IO.println(sb01);
        IO.println(System.identityHashCode(sb01));

        // StringBuffer : ThreadSafe 보장
        // StringBuilder : 동기화 처리가 없어 단일 thread일 때 더 빠름
        StringBuffer sb02 = new StringBuffer("java");
        IO.println(sb02);
        IO.println(System.identityHashCode(sb02));

        sb02.append("!!");
        IO.println(sb02);
        IO.println(System.identityHashCode(sb02));
    }
}