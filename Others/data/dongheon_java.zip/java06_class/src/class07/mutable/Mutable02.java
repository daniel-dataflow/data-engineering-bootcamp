package class07.mutable;

public class Mutable02 {
    void main() {
        mutable();
        immutable();
    }

    public static void mutable() {
        Human human = new Human("hong-gd", 10);
        IO.println(human.name);
        IO.println(System.identityHashCode(human));

        human.name = "홍길동";
        IO.println(human.name);
        IO.println(System.identityHashCode(human));
    }

    public static void immutable() {
        Person person = new Person("hong-gd", 10);
        IO.println(person);
        IO.println(System.identityHashCode(person));
        // person.name = "홍길동";
        // record는 immutable한 data object (= ValueObject) 를 생성하기 위한 특수클래스
    }
}
