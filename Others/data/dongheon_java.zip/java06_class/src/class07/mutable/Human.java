package class07.mutable;

public class Human {
    String name;
    int age;

    public Human(String name, int age){
        this.name = name;
        this.age = age;
    }
}
