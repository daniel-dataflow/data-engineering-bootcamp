package class07.mutable;

public record Person(String name, int age) {
}
