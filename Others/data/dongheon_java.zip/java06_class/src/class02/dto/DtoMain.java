package class02.dto;

import java.time.LocalDate;

public class DtoMain {
    void main() {
        // DTO : Data Transfer Object - layer 간 data 전송 (가변적)
        // VO : Value Object - 값 객체 (불변)

        String id = "admin";
        String password = "1234";
        String name = "hong-gd";
        int age = 100;
        LocalDate birthday = LocalDate.of(2000, 1, 1);
        String address = "Seoul";
        String phone = "010-1234-5678";

        DataTransferObject01 dto01 =
                new DataTransferObject01(id, password, name, age, birthday, address, phone);

        IO.println(dto01);

        DataTransferObject02 dto02 =
                new DataTransferObject02(id, password, name, age, birthday, address, phone);
        IO.println(dto02);

        // 같은 내용으로 변수만 달라짐
        DataTransferObject01 dto03 =
                new DataTransferObject01(id, password, name, age, birthday, address, phone);
        DataTransferObject02 dto04 =
                new DataTransferObject02(id, password, name, age, birthday, address, phone);

        // == : 주소값 비교
        IO.println(dto01 == dto03);
        IO.println(dto02 == dto04);
        // .equals : 객체 안에 있는 값 비교
        // equals를 override 하지 않았으면 == 으로 동작!
        IO.println(dto01.equals(dto03));
        // equals도 override 되어있구나.
        IO.println(dto02.equals(dto04));

    }
}
