package basic.operator;

public class BasicOperator {

    // final : 상수
    static final int TEN = 10;

    void main() {
        IO.println("1. 괄호 ()");
        int result01 = (TEN + 3) * 4;
        IO.println(result01);
        int result02 = TEN + 3 * 4;
        IO.println(result02);

        IO.println("2. 증감 / 단항 (++ -- ! ~)");
        /*
        ++, --
        변수의 앞뒤에 증감연산자를 붙이게 되면, 변수가 가진 값을 1씩 증감 하게 된다.
        전위 연산자 (++i) : 연산자를 변수 앞에 붙여서 연산을 먼저 하게 되고, 값을 나중에 리턴한다.
        후위 연산자 (i++) : 연산자를 변수 뒤에 붙여서 값을 먼저 리턴하고, 연산을 나중에 하게 된다.
         */
        int i = TEN;
        IO.println(++i);
        IO.println(i++);
        IO.println(i);

        int a = 10;
        int b = 2;
        int c = a++ + --b + b++ + ++a;
        //      10(11) + 1(1) + 1(2) + 12(12) -> a:12 / b: 2 / c: 24
        IO.println(a);
        IO.println(b);
        IO.println(c);

        // ! : not
        IO.println(!true);
        IO.println(!false);
        // ~ : 비트 반전
        IO.println(~TEN);
        // 0000 0000 0000 0000 0000 0000 0000 1010 (10)
        // 1111 1111 1111 1111 1111 1111 1111 0101 (-11)

        IO.println("3. 산술 (* / %)");
        int result03 = TEN + 6 / 2;
        int result04 = TEN % 6 * 2;
        IO.println(result03);
        IO.println(result04);

        IO.println("4. 산술 (+ -)");
        int result05 = TEN - 6 + 2;
        IO.println(result05);

        IO.println("5. 시프트 (<< >> <<< >>>)");
        int positiveTen = 10;
        // 0000 0000 0000 0000 0000 0000 0000 1010 (10)
        int negativeTen = -10;
        // 1111 1111 1111 1111 1111 1111 1111 0110 (2의 보수)

        int leftShiftPositive = positiveTen << 2;
        // 0000 0000 0000 0000 0000 0000 0000 1010 (10)
        // 0000 0000 0000 0000 0000 0000 0010 1000 (40)

        int rightShiftPositive = positiveTen >> 2;
        // 0000 0000 0000 0000 0000 0000 0000 1010 (10)
        // 0000 0000 0000 0000 0000 0000 0000 0010 (2)

        int unsignedRightShiftPositive = positiveTen >>> 2;
        // 0000 0000 0000 0000 0000 0000 0000 1010 (10)
        // 0000 0000 0000 0000 0000 0000 0000 0010 (2)

        int leftShiftNegative = negativeTen << 2;
        // 1111 1111 1111 1111 1111 1111 1111 0110 (-10)
        // 1111 1111 1111 1111 1111 1111 1101 1000 (-40)

        int rightShiftNegative = negativeTen >> 2;
        // 1111 1111 1111 1111 1111 1111 1111 0110 (-10)
        // 1111 1111 1111 1111 1111 1111 1111 1101 (-3)

        int unsignedRightShiftNegative = negativeTen >>> 2;
        // 1111 1111 1111 1111 1111 1111 1111 0110 (-10)
        // 0011 1111 1111 1111 1111 1111 1111 1101 (1073741821)

        IO.println(leftShiftPositive);
        IO.println(rightShiftPositive);
        IO.println(unsignedRightShiftPositive);

        IO.println(leftShiftNegative);
        IO.println(rightShiftNegative);
        IO.println(unsignedRightShiftNegative);

        IO.println("6. 비교 (< > <= >= instanceof)");
        boolean result08 = TEN > 5 + 3;
        boolean result09 = TEN <= 5 + 3;
        IO.println(result08);
        IO.println(result09);

        Integer integer = Integer.valueOf(10);
        boolean result10 = integer instanceof Integer;
        IO.println(result10);

        IO.println("7. 동등 (== !=)");
        IO.println(TEN == 10);
        IO.println(TEN != 10);

        IO.println("8. 비트 AND (&)");
        int result11 = TEN & 2;
        // 0000 0000 0000 0000 0000 0000 0000 1010 (10)
        // 0000 0000 0000 0000 0000 0000 0000 0010 (2)
        // 0000 0000 0000 0000 0000 0000 0000 0010 (10 & 2 : 둘 다 1이면 1)
        IO.println(result11);

        IO.println("9. 비트 XOR (^)");
        int result12 = TEN ^ 2;
        // 0000 0000 0000 0000 0000 0000 0000 1010 (10)
        // 0000 0000 0000 0000 0000 0000 0000 0010 (2)
        // 0000 0000 0000 0000 0000 0000 0000 1000 (10 ^ 2 : 같으면 0 다르면 1)
        IO.println(result12);

        IO.println("10. 비트 OR (|)");
        int result13 = TEN | 2;
        // 0000 0000 0000 0000 0000 0000 0000 1010 (10)
        // 0000 0000 0000 0000 0000 0000 0000 0010 (2)
        // 0000 0000 0000 0000 0000 0000 0000 1010 (10 | 2 : 하나라도 1이면 1)
        IO.println(result13);

        // && : 왼쪽의 조건이 거짓이면 오른쪽의 조건을 수행하지 않고 false 리턴 (어차피 false)
        IO.println("11. 논리 AND (&&)");
        boolean result14 = false && (TEN == 10);
        IO.println(result14);

        // || : 왼쪽의 조건이 참이면 오른쪽의 조건을 수행하지 않고 true 리턴 (어짜피 true)
        IO.println("12. 논리 OR (||)");
        boolean result15 = true || (TEN == 10);
        IO.println(result15);

        IO.println("13. 삼항 연산자 (?:)");
        int result16 = (10 > 5) ? 100 : 200;
        IO.println(result16);

        IO.println("14. 대입 (=, 복합대입)");
        int result17 = TEN;
        result17 = result17 + 5;
        IO.println(result17);
        result17 += 5;
        IO.println(result17);
    }
}
