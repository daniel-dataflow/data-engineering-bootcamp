module java15.module {
    // 다른 module에서 사용할 수 있도록 공개
    exports member.dto;
    exports member.service;
}
