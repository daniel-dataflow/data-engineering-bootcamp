package member.service;

import member.dto.Member;

public class MemberService {

    public Member findMember(String id) {
        return new Member(id, "홍길동");
    }
}
