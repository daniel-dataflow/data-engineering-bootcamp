package thread03.virtual;

import java.util.concurrent.Executors;
import java.util.stream.IntStream;

public class VirtualMain02 {
    void main() {
        platformThread();
        virtualThread();
    }

    public static void platformThread() {
        long start = System.currentTimeMillis();

        try (var executor = Executors.newFixedThreadPool(1000)) {
            IntStream.range(0, 100_000).forEach(i -> {
                executor.submit(() -> {
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    return i;
                });
            });
        }

        long end = System.currentTimeMillis();
        IO.println("Platform Thread : " + (end - start) + "ms");
    }

    public static void virtualThread() {
        long start = System.currentTimeMillis();

        // 가상 스레드는 풀링하지 않고 "작업당 스레드 하나"를 할당함
        try (var executor = Executors.newVirtualThreadPerTaskExecutor()) {
            IntStream.range(0, 100_000).forEach(i -> {
                executor.submit(() -> {
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    return i;
                });
            });
        }

        long end = System.currentTimeMillis();
        IO.println("Virtual Thread : " + (end - start) + "ms");
    }
    /*
    CPU 연산에서는 platform thread (기존에 사용해 오던 방식) 과 비슷하거나, 오히려 platform thread가 더 빠를 수 있음
    -> 실제로 실행하는 cpu는 유한하기 때문 (context switching 비용 발생)
    File IO / Network / DataBase 등의 작업 (thread가 기다리는 작업) 을 할 때 virtual thread가 훨씬 빠름
     */
}
