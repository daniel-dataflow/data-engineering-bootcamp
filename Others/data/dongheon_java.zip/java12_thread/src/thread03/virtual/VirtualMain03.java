package thread03.virtual;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.StructuredTaskScope;
import static java.util.concurrent.Executors.newVirtualThreadPerTaskExecutor;
import java.util.stream.IntStream;


public class VirtualMain03 {
    void main() {
        structuredConcurrency();
        blockingIO();
    }

    public static void structuredConcurrency() {
        // StructuredTaskScope : 여러 개의 작업을 하나로
        try (var scope = StructuredTaskScope.open()) {
            // fork : virtual thread (default) 로 작업 시작
            var f1 = scope.fork(() -> {
                Thread.sleep(500);
                return "result01";
            });

            var f2 = scope.fork(() -> {
                Thread.sleep(300);
                return "result02";
            });

            // blocking (scope 안의 모든 sub task가 끝날 때 까지 대기)
            scope.join();

            IO.println("Structured results: " + f1.get() + ", " + f2.get());

        } catch (InterruptedException e) {
            e.printStackTrace();

        } catch (StructuredTaskScope.FailedException e) {
            // 서브태스크 중 하나가 실패한 경우
            e.printStackTrace();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void blockingIO() {
        Path outputFile = Path.of("blocking.txt");

        // newVirtualThreadPerTaskExecutor : task 가 새로 실행될 때 마다 새로운 virtual thread 생성 (pooling하지 않는다)
        try (var executor = newVirtualThreadPerTaskExecutor()) {
            IntStream.range(0, 5).forEach(i -> {
                executor.submit(() -> {
                    try {
                        String content = "hello world task " + i + "\n";

                        // virtual thread가 blocking IO 중이어도 OS thread (Kernel thread) 를 점유하지 않음
                        // -> 다른 virtual thread가 그 OS thread를 사용해 동시에 실행 가능
                        Files.writeString(outputFile, content,
                                java.nio.file.StandardOpenOption.CREATE,
                                java.nio.file.StandardOpenOption.APPEND);
                        IO.print(content);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                });
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
