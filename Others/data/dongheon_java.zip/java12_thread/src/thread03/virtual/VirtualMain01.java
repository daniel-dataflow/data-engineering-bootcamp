package thread03.virtual;

import java.util.concurrent.Executors;

public class VirtualMain01 {
    void main() throws InterruptedException {
        // 방법 1: 즉시 실행 (Thread.startVirtualThread)
        Thread vThread1 = Thread.startVirtualThread(() -> {
            IO.println(Thread.currentThread());
        });

        // 방법 2: 빌더를 사용한 생성 (Thread.ofVirtual())
        Thread vThread2 = Thread.ofVirtual()
                // 이름 설정 가능
                .name("my-virtual-thread")
                .unstarted(() -> {
                    IO.println(Thread.currentThread());
                });
        vThread2.start();

        // 방법 3: ExecutorService 사용 (공식 문서 권장 방식)
        // try-with-resources를 쓰면 작업 완료 시까지 자동으로 기다림(close/shutdown)
        try (var executor = Executors.newVirtualThreadPerTaskExecutor()) {
            executor.submit(() -> IO.println(Thread.currentThread()));
        }

        vThread1.join();
        vThread2.join();
    }}
