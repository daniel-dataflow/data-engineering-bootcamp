package thread01.basic;

public class ThreadMain02 {
    void main() throws InterruptedException {
        Thread thread = new Thread(() -> {
            for (int i = 1; i <= 5; i++) {
                IO.println("sub thread : " + i);
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        });

        thread.start();

        for (int i = 1; i <= 5; i++) {
            IO.println("main thread : " + i);
            Thread.sleep(200);
        }

        thread.join();
        IO.println("join : 다른 thread가 종료될 때 까지 기다림");
    }
}
