package thread01.basic;

public class ThreadMain03 {
    void main() throws InterruptedException {
        Thread daemonThread = new Thread(() -> {
            while (true) {
                IO.print("♥");
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    break;
                }
            }
        });
        // 다른 thread가 종료 될 때 까지 background 실행
        daemonThread.setDaemon(true);
        daemonThread.start();

        // 10초 후 종료
        Thread.sleep(10000);
    }
}
