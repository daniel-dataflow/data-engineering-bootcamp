package thread01.basic;

public class ThreadMain04 {
    void main() {
        try {
            Counter01 counter01 = new Counter01();
            Counter02 counter02 = new Counter02();

            threadRunningProcess(counter01);
            threadRunningProcess(counter02);

        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public static void threadRunningProcess(Object counter) throws InterruptedException {
        Runnable r = () -> {
            for (int i = 0; i < 100000; i++) {
                if (counter instanceof Counter01 c01) {
                    c01.increment();
                } else if (counter instanceof Counter02 c02) {
                    c02.increment();
                }
            }
        };

        Thread t01 = new Thread(r);
        Thread t02 = new Thread(r);

        t01.start();
        t02.start();

        t01.join();
        t02.join();

        if (counter instanceof Counter01 c01) {
            IO.println("unsafe (thread01) : " + c01.getCount());
        } else if (counter instanceof Counter02 c02) {
            IO.println("safe (thread02) : " + c02.getCount());
        }
    }
}
