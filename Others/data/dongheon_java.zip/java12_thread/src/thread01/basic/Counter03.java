package thread01.basic;

import java.util.concurrent.atomic.AtomicInteger;

public class Counter03 {
    // Atomic Class : Lock-free / CAS(Compare-And-Swap)알고리즘 사용 (hardware 방식) - 단순 작업일 때
    private AtomicInteger count = new AtomicInteger(0);

    public void increment() {
        count.incrementAndGet();
    }

    public int getCount() {
        return count.get();
    }
}
