package thread01.basic;

public class ThreadMain01 {
    void main() {
        IO.println("main thread start");
        // extends Thread
        Thread01 theard01 = new Thread01();

        // implements Runnable
        Thread theard02 = new Thread(new Thread02());

        IO.println("threads start");
        // thread.start() = run() 호출
        theard01.start();
        theard02.start();

        IO.println("main thread end");
    }
}
