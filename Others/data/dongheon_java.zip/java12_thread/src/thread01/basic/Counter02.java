package thread01.basic;

public class Counter02 {
    private int count = 0;

    // synchronized : Lock (software 방식) - 복잡한 작업일 때
    // lock : resource 에 동시에 접근하지 못하도록 잠금 (한 번에 하나의 thread만 resource에 접근 가능)
    public synchronized void increment() {
        count++;
    }

    public int getCount() {
        return count;
    }
}
