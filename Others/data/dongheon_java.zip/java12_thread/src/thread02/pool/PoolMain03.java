package thread02.pool;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

public class PoolMain03 {
    static int count = 0;
    static ReentrantLock lock = new ReentrantLock();

    void main() throws InterruptedException {
        ExecutorService pool = Executors.newFixedThreadPool(3);

        Runnable task = () -> {
            for (int i = 0; i < 1000; i++) {
                lock.lock();
                try {
                    IO.println(count++ + "\t" + Thread.currentThread().getName());
                } finally {
                    lock.unlock();
                }
            }
        };

        for (int i = 0; i < 5; i++) {
            pool.execute(task);
        }

        pool.shutdown();
        pool.awaitTermination(3, TimeUnit.SECONDS);

        IO.println("count : " + count);
    }
}
