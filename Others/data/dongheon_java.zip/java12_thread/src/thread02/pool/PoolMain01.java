package thread02.pool;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PoolMain01 {
    void main() {
        ExecutorService pool = Executors.newFixedThreadPool(3);

        for (int i = 0; i < 10; i++) {
            int taskId = i;
            pool.execute(() -> {
                IO.println(
                        Thread.currentThread().getName() + " : " + taskId
                );
            });
        }

        // 작업이 완료되었으면 pool 종료!
        pool.shutdown();
    }
}
