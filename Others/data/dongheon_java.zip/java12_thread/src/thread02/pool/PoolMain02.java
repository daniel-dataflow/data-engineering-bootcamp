package thread02.pool;

import java.util.concurrent.*;

public class PoolMain02 {
    void main() throws ExecutionException, InterruptedException {
        future01();
        future02();
    }

    public static void future01() throws ExecutionException, InterruptedException {
        ExecutorService pool = Executors.newFixedThreadPool(5);

        Callable<Integer> task = () -> {
            int sum = 0;
            for (int i = 1; i <= 100; i++) sum += i;
            Thread.sleep(500);
            return sum;
        };

        // submit : non blocking
        Future<Integer> future = pool.submit(task);

        // get : blocking (5개의 executor가 모든 작업을 다 할 때까지 main thread가 기다림)
        Integer result = future.get();
        IO.println("result : " + result);

        // 새로운 작업 X
        pool.shutdown();
        // awaitTermination : blocking (5초 기다렸다가 pool 삭제 - 그 전에 pool 안의 task가 모두 종료되면 자동으로 다음 코드로 넘어감)
        if (!pool.awaitTermination(5, TimeUnit.SECONDS)) {
            // pool 내부의 작업 강제로 종료
            pool.shutdownNow();
        }

        IO.println("future01");
    }

    public static void future02() throws InterruptedException {
        ExecutorService pool = Executors.newFixedThreadPool(5);

        // supplyAsync: 비동기로 1~100 합계 계산 (callable의 역할)
        // non blocking : 5개의 executor가 하는 작업이 모두 완료되는 것을 main thread가 기다리지 않음
        CompletableFuture.supplyAsync(() -> {
                    int sum = 0;
                    for (int i = 1; i <= 100; i++) sum += i;
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    return sum;
                }, pool)
                // thenAccept: 계산이 완료되면 그 결과를 받아 출력 (결과 처리)
                .thenAccept(result -> {
                    IO.println("result : " + result);
                })
                // exceptionally: 에러 발생 시 처리 (try-catch 역할)
                .exceptionally(e -> {
                    e.printStackTrace();
                    return null;
                });

        pool.shutdown();
        if (!pool.awaitTermination(5, TimeUnit.SECONDS)) {
            pool.shutdownNow();
        }
        IO.println("future02");
    }
}