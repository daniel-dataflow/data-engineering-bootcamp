module java14.module {
    // java15.module 사용
    requires java15.module;
}
