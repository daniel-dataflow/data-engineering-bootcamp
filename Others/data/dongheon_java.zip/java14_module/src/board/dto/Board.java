package board.dto;

public class Board {
    private String title;
    private String writer;

    public Board(String title, String writer) {
        this.title = title;
        this.writer = writer;
    }

    public String getTitle() {
        return title;
    }

    public String getWriter() {
        return writer;
    }
}
