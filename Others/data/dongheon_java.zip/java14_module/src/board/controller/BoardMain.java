package board.controller;

import board.dto.Board;
import board.service.BoardService;

public class BoardMain {
    void main() {
        BoardService boardService = new BoardService();
        Board board = boardService.createBoard("user01", "모듈 어렵다");

        IO.println(board.getTitle());
        IO.println(board.getWriter());
    }
}
