package board.service;

import board.dto.Board;
import member.dto.Member;
import member.service.MemberService;

public class BoardService {

    private final MemberService memberService = new MemberService();

    public Board createBoard(String memberId, String title) {
        Member member = memberService.findMember(memberId);
        return new Board(title, member.getName());
    }
}
