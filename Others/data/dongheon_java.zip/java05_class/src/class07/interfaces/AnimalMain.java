package class07.interfaces;

public class AnimalMain {
    void main() {
        Animal dog = new Dog();
        Animal cat = new Cat();

        dog.bark();
        cat.bark();

        dog.sleep();
        cat.sleep();

        Animal.eat();

        IO.println(Animal.country);
    }
}
