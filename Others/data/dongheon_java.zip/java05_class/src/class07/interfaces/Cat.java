package class07.interfaces;

public class Cat implements Animal{

    @Override
    public void bark() {
        IO.println("야옹");
    }

    @Override
    public void sleep() {
        IO.println("야옹이는 낮잠도 잘자요");
    }
}
