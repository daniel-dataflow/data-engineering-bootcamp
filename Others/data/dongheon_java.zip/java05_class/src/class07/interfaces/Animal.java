package class07.interfaces;

// 기본적으로 method가 abstract method 임을 가정
public interface Animal {
    // public staitc final 생략 (= constant)
    // 추가로 기억! class에 final이 붙으면 상속 불가!
    String country = "zootopia";

    // abstract method : 자식 class에서 반드시 구현
    void bark();

    // defaulut method : 상속받는 자식 class들의 공통 기능을 미리 구현
    default void sleep() {
        printSound("zzz");
    }

    // static method : 객체 없이 사용하기 위한 기능
    static void eat() {
        printSound("쩝쩝");
    }

    // private method : default / static method 에서 공통 로직을 encapsulation
    private static void printSound(String sound) {
        IO.println(sound);
    }
}
