package class07.interfaces;

public class Dog implements Animal{

    @Override
    public void bark() {
        IO.println("멍멍");
    }
}
