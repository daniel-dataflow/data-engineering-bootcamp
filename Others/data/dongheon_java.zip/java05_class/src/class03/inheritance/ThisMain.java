package class03.inheritance;

public class ThisMain {
    void main() {
        This01 this01 = new This01();
        // upcasting (자식 -> 부모는 자동으로 형변환 가능)
        Super super01 = this01;
        IO.println(this01);
        IO.println(super01);

        Super super02 = new This02();
        // downcasting (부모 -> 자식은 명시적으로 형변환)
        This02 this02 = (This02) super02;
        IO.println(this02);
        IO.println(super02);

        // compile 시엔 에러가 안남
        // runtime 에서 에러가 남 (java.lang.ClassCastException)
        This01 this03 = (This01) super02;
        IO.println(this03);
        /*
        compile 에서는 error 가 나지 않는 이유
        - java는 정적 타입 체크 (static type checking) : compiler는 변수의 선언된 타입만 가지고 타입 검사 (문법적으로 맞는지만 확인)
        runtime 에서 error 가 나는 이유
        - jvm (실행 환경)이 실행하면서 instanace의 type이 casting하려는 type과 다르기 때문에 ClassCastException

        [type checking]
        static type: compile 시 타입을 검사하고 변수 타입을 미리 정의함
        dynamic type: runtime 시 타입을 검사하고 변수의 타입은 값에 따라 결정됨 (타입 추론)

        [type conversion]
        strong type: 타입에 대해 엄격함 (서로 다른 타입끼리는 암시적 변환이 거의 없음)
        weak type: 타입에 대해 느슨함 (암시적 타입 변환이 자주 발생함)
        */
    }
}
