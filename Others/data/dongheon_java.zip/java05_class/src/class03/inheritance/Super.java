package class03.inheritance;

public class Super {
    public Super() {
        IO.println("super 생성");
    }
}
