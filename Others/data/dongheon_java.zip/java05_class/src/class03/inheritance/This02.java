package class03.inheritance;

public class This02 extends Super{
    public This02() {
        IO.println("this02 생성");
    }
}
