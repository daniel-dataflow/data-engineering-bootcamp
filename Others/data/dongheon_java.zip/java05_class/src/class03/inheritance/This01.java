package class03.inheritance;

public class This01 extends Super{
    public This01() {
        super();
        IO.println("this01 생성");
    }
}
