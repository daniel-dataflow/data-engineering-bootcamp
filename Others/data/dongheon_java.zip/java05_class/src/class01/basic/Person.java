package class01.basic;


import java.time.LocalDate;

// public class Parent extends Object -> java의 모든 class의 최상위 클래스 (조상) 은 Object class
public class Person {

    // member : field + method

    // field
    // instance variable
    private String name;
    private int age;

    // static variable
    public static int peopleCount = 0;

    // final variable (= constant)
    final LocalDate birthday;

    // constructor (생성자) -> 객체 생성, 필드 초기화
    public Person() {
        // this : 나 객체
        this.name = "hong-gd";
        this.age = 0;
        this.birthday = LocalDate.now();
        IO.println("Person 생성");
        peopleCount++;
    }

    // 생성자 오버로딩
    public Person(String name, int age, LocalDate birthday) {
        this.name = name;
        this.age = age;
        this.birthday = birthday;
        IO.println("Person 생성");
        peopleCount++;
    }

    // method
    // getter, setter
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        // this.age = age;

        // encapsulation (instance 변수를 외부에서 바로 접근하지 못하게 하고, method로만 사용 가능)
        // -> 변수는 아래와 같은 작업을 할 수 없으니까
        if (age > 0) {
            this.age = age;
        } else {
            this.age = 0;
        }
    }

    public String personInfo() {
        // %3$tY : 3$ -> 3번째 arg 사용, tY : time Year
        // instance member 인 경우에, this 생략 가능
        return String.format("name : %s \t age : %d \t birthday : %3$tY-%3$tm-%3$td", name, age, birthday);
    }

    // final이 붙으면 상속되지 않는다.
    public static final int getPeopleCount() {
        return peopleCount;
    }
    /*
    class 안에 constructor를 작성하지 않으면 runtime 시 default constructor를 자동으로 생성. -> 내부적으로 super() 호출만 한다.
    만일, parameter가 있는 constructor를 작성하면, default constructor는 생성되지 않는다.
     */
}
