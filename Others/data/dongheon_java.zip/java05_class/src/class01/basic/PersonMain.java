package class01.basic;

import java.time.LocalDate;

public class PersonMain {
    void main() {
        // class 변수 = new constructor(); -> instance
        Person hong = new Person();
        IO.println(hong);

        IO.println(hong.getName());
        IO.println(hong.getAge());
        IO.println(hong.personInfo());

        Person lee = new Person("lee-ss", 100, LocalDate.of(2000, 1, 1));
        IO.println(lee.personInfo());
        lee.setName("이순신");
        IO.println(lee.personInfo());

        // static 변수는 class(type) 전체에 적용
        IO.println(Person.getPeopleCount());
    }
}
