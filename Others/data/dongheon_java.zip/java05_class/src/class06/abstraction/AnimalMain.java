package class06.abstraction;

public class AnimalMain {
    void main() {
        // abstract class는 instantiation 불가
        // Animal animal = new Animal();

        Dog dog = new Dog();
        dog.bark();
        dog.eat("참치");

        Cat cat = new Cat();
        cat.bark();
        cat.eat("뼈다귀");
    }
}
