package class06.abstraction;

public class Cat extends Animal{
    @Override
    public void bark() {
        IO.println("야옹");
    }

    public void eat(String feed) {
        IO.print("멍멍이가 ");
        super.eat(feed);
    }
}
