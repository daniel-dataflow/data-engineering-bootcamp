package class06.abstraction;

// abstract class : abstract method를 가질 수 있는 class
// instance 생성 불가!
public abstract class Animal {

    // abstract method : 상속받는 자식 클래스에서 반드시 override 해서 구현
    public abstract void bark();

    public void eat(String feed) {
        IO.println(feed + "먹는다.");
    }
}
