package class06.abstraction;

public class Dog extends Animal{
    @Override
    public void bark() {
        IO.println("멍멍");
    }
}
