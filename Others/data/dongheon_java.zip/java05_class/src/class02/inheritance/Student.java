package class02.inheritance;

import class01.basic.Person;

import java.time.LocalDate;

// Inheritance : Person을 상속한 Student
public class Student extends Person {

    private String school;

    // 기본생성자
    public Student() {
        // super() : 부모 생성자 호출 (기본생성자 인 경우 생략 가능)
        this.school = "조선학당";
        IO.println("Student 생성");
    }

    public Student(String name, int age, LocalDate birthday) {
        super(name, age, birthday);
        this.school = "조선초등학교";
        IO.println("Student 생성");
    }

    public Student(String name, int age, LocalDate birthday, String school) {
        super(name, age, birthday);
        this.school = school;
        IO.println("Student 생성");
    }

    // overriding : 재정의 (부모의 것을 내가 맘대로 사용
    @Override
    public String personInfo() {
        return String.format("%s \t school : %s", super.personInfo(), this.school);
    }

    public String studentInfo() {
        // birthday는 final 이기 때문에 상속되지 않음!
        return String.format("name : %s \t age : %d \t school : %s", super.getName(), super.getAge(), this.school);
    }

}
