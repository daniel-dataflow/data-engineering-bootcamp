package class02.inheritance;

import class01.basic.Person;

public class StudentMain {
    void main() {
        // 자식 객체를 생성해도 부모가 먼저 생성
        Student hong = new Student();
        // 부모의 기능 자식이 사용 (상속)
        IO.println(hong.getName());
        IO.println(hong.getAge());
        IO.println(hong.personInfo());
        IO.println(hong.studentInfo());

        // 다형성 (Polimorphism) : 같은 method를 호출했지만, 실제 객체의 type에 따라 다른 동작
        Person a = new Person();
        IO.println(a.personInfo());
        // Person 이 Student 보다 상위타입이기 때문에 auto-upcasting 발생
        // 부모-자식 / 조상-후손 으로 보통 이야기함
        Person b = new Student();
        IO.println(b.personInfo());
    }
}
