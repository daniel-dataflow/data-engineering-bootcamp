package class08.interfaces;

// extends/implements Animal -> interface는 class 상속 불가
public interface Eagle {
    void fly();
}
