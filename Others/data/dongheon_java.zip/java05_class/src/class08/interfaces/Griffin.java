package class08.interfaces;

// class는 단일 상속, interface는 다중 구현으로 OOP의 다중 상속 효과를 구현
public class Griffin extends Lion implements Eagle, Fantasy{

    @Override
    public void fly() {
        IO.println("그리핀이 파닥파닥");
    }

    @Override
    public void bark() {
        IO.println("그리핀이 삐약삐약");
    }

    @Override
    public void born() {
        IO.println("환상의 포X몬? 그리핀!!");
    }
}
