package class08.interfaces;

public abstract class Animal {
    public abstract void bark();
}
