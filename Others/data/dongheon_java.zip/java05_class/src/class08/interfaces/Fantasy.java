package class08.interfaces;

public interface Fantasy {
    void born();
}
