package class08.interfaces;

public class Lion extends Animal{
    @Override
    public void bark() {
        IO.println("사자가 크앙");
    }
}
