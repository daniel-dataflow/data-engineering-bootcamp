package class08.interfaces;

public class AnimalMain {
    void main() {
        Griffin griffin = new Griffin();
        griffin.born();
        griffin.fly();
        griffin.bark();
    }
}
