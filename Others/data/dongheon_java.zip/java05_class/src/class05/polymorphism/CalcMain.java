package class05.polymorphism;

public class CalcMain {
    void main() {
        Calculator calc = new Calculator();

        IO.println(calc.sum(1));
        IO.println(calc.sum(1, 2));
        IO.println(calc.sum(1, 2, 3));
        IO.println(calc.sum(1.2, 3.4));
    }
}

