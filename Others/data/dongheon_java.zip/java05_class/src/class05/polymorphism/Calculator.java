package class05.polymorphism;

import java.util.Arrays;

public class Calculator {
    public int sum(int i) {
        return i + 1;
    }

    public int sum(int i, int j) {
        return i + j;
    }

    public int sum(int i, int j, int k) {
        return i + j + k;
    }

    public double sum(double d, double e) {
        return d + e;
    }
}
