package class04.polymorphism;

public class Dog extends Animal{
    public Dog() {
        IO.println("멍멍이");
    }

    @Override
    public void bark() {
        IO.println("멍멍");
    }
}
