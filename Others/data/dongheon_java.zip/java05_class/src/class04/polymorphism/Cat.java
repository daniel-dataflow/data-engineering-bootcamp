package class04.polymorphism;

public class Cat extends Animal{
    public Cat() {
        IO.println("고양이");
    }
}
