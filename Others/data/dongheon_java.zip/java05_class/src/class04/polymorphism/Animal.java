package class04.polymorphism;

public class Animal {

    public void bark(){
        IO.println("소리");
    }

}
