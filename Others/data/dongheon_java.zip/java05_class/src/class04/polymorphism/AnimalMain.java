package class04.polymorphism;

public class AnimalMain {
    void main() {
        Cat cat = new Cat();
        Dog dog = new Dog();

        cat.bark();
        dog.bark();

        Animal animal = null;
        String select = IO.readln("1: Dog\n2: Cat\n숫자 입력 : ");

        animal = switch (Integer.parseInt(select)) {
            case 1 -> new Dog();
            case 2 -> new Cat();
            default -> new Animal();
        };

        // polimorphism (다형성) : overloading, overriding 을 사용하여, 같은 메서드 이름으로 다양한 동작을 처리할 수 있음
        animal.bark();
    }
}
