package network02.tcp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server01 {
    void main() {
        int port = 8081;
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            IO.println("server started (port : " + port + ")\t wait... ");

            Socket clientSocket = serverSocket.accept();
            IO.println("client : " + clientSocket.getInetAddress());

            BufferedReader in = new BufferedReader(
                    new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

            String msg;
            while ((msg = in.readLine()) != null) {
                IO.println("client message : " + msg);
                out.println(msg);
                if (msg.equalsIgnoreCase("bye")) {
                    break;
                };
            }
            clientSocket.close();
            IO.println("server end");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
