package network02.tcp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class Client02 {
    void main() {
        String host = "localhost";
        int port = 8082;

        try (Socket socket = new Socket(host, port)) {
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

            Thread.ofVirtual().start(() -> {
                try {
                    String serverResponse;
                    while ((serverResponse = in.readLine()) != null) {
                        IO.println(serverResponse);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });

            String msg;
            while (true) {
                msg = IO.readln();
                out.println("client message : " + msg);

                if (msg.equalsIgnoreCase("bye")) {
                    IO.println("client end");
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
