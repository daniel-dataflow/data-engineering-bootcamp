package network02.tcp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class Client01 {
    void main() {
        String host = "localhost";
        int port = 8081;

        try (Socket socket = new Socket(host, port)) {
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

            String msg;
            while ((msg = IO.readln("message : ")) != null) {
                out.println(msg);
                IO.println("response : " + in.readLine());
                if (msg.equalsIgnoreCase("bye")) {
                    IO.println("client end");
                    break;
                };
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
