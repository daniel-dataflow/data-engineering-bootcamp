package network02.tcp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server02 {
    void main() {
        int port = 8082;
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            IO.println("server started (port : " + port + ")\t wait... ");

            Socket clientSocket = serverSocket.accept();
            IO.println("client : " + clientSocket.getInetAddress());

            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

            Thread.ofVirtual().start(() -> {
                try {
                    String clientMsg;
                    while ((clientMsg = in.readLine()) != null) {
                        IO.println(clientMsg);
                        if (clientMsg.equalsIgnoreCase("bye")) {
                            break;
                        };
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });

            String serverMsg;
            while (true) {
                serverMsg = IO.readln();

                out.println("server message : " + serverMsg);

                if (serverMsg.equalsIgnoreCase("bye")) {
                    IO.println("server end");
                    break;
                }
            }
            clientSocket.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
