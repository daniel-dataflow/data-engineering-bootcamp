package network03.udp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class Server {
    void main() {
        String host = "localhost";
        int port = 8083;
        int clientPort = 8084;
        byte[] buffer = new byte[1024];

        try (DatagramSocket socket = new DatagramSocket(port)) {
            IO.println("server started (port : " + port + ")\t wait... ");

            Thread.ofVirtual().start(() -> {
                try {
                    while (true) {
                        DatagramPacket receivePacket = new DatagramPacket(buffer, buffer.length);
                        socket.receive(receivePacket);

                        String msg = new String(receivePacket.getData(), 0, receivePacket.getLength());
                        IO.println(msg);
                        if (msg.contains("bye")) break;
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });

            InetAddress clientAddress = InetAddress.getByName(host);

            while (true) {
                String serverMsg = IO.readln();
                byte[] sendData = ("server message : " + serverMsg).getBytes();

                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, clientAddress, clientPort);
                socket.send(sendPacket);

                if (serverMsg.equalsIgnoreCase("bye")) {
                    IO.println("server end");
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}