package network03.udp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class Client {
    void main() {
        String host = "localhost";
        int serverPort = 8083;
        int myPort = 8084;
        byte[] buffer = new byte[1024];

        try (DatagramSocket socket = new DatagramSocket(myPort)) {
            InetAddress serverAddress = InetAddress.getByName(host);

            Thread.ofVirtual().start(() -> {
                try {
                    while (true) {
                        DatagramPacket receivePacket = new DatagramPacket(buffer, buffer.length);
                        socket.receive(receivePacket);

                        String response = new String(receivePacket.getData(), 0, receivePacket.getLength());
                        IO.println(response);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });

            while (true) {
                String msg = "client message : " + IO.readln();
                byte[] sendData = msg.getBytes();

                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, serverAddress, serverPort);
                socket.send(sendPacket);

                if (msg.equalsIgnoreCase("bye")) {
                    IO.println("client end");
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}