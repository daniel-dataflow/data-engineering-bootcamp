package network01.http;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class HttpMain {
    void main() throws IOException, InterruptedException, URISyntaxException {
        HttpClient client = HttpClient.newHttpClient();

        HttpRequest request = HttpRequest.newBuilder()
                .uri(new URI("https://www.google.com"))
                .GET()
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        IO.println("status code : " + response.statusCode());
        IO.println("request uri: " + response.request().uri());
        IO.println("request method: " + response.request().method());
        IO.println("status code : " + response.version());

        IO.println("---");

        response.headers()
                .map()
                .entrySet()
                .stream()
                .flatMap(entry -> entry.getValue().stream()
                        .map(value -> entry.getKey() + " : " + value))
                .forEach(IO::println);
    }
}
