package exception02.custom;

public class MyException extends Exception{
    public MyException(){
        super("내가 만든 예외입니다.");
    }
}
