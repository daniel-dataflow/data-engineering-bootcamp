package exception02.custom;

public class ExceptionMain {
    void main() {
        try {
            int a = 1;
            int b = 2;

            if (a + b == 3) {
                // throw :  예외 강제 발생
                throw new MyException();
            }
        } catch (MyException e) {
            System.out.println(e.getMessage());
        }
    }
}
