package exception01.basic;

public class Exception01 {
    /*
    try {
        // 예외가 발생할 수 있는 코드
    } catch (Exception e) {
        // 예외 발생 시 실행
    } finally {
        // 예외 발생 여부와 상관없이 항상 실행
    }
     */

    void main() {
        // exception01();
        exception02();
        exception03();
        // exception04();
        exception05();
        exception06();
        exception07();
        exception08();
    }

    public static void exception01() {
        // ArithmeticException
        IO.println(10 / 0);
    }

    public static void exception02() {
        try {
            IO.println(10 / 0);
        } catch (Exception e) {
            IO.println("예외 발생");
            IO.println(e);
        }
    }

    public static void exception03() {
        try {
            IO.println(10 / 0);

            // ArithmeticException만 처리
        } catch (ArithmeticException e) {
            IO.println("0으로 나눌 수 없습니다.");
        }
    }

    static void exception04() {
        try {
            int[] a = {1, 2, 3, 4, 5};
            IO.println(a[5]);

            // ArrayIndexOutOfBoundsException은 여기 안 걸림
        } catch (ArithmeticException e) {
            System.out.println("0으로 나눌 수 없습니다.");
        }
    }

    public static void exception05() {
        try {
            int[] a = {1, 2, 3, 4, 5};
            IO.println(a[5]);

            // 다중 catch (발생할 수 있는 exception 별로 다른 동작)
        } catch (ArithmeticException e) {
            IO.println("0으로 나눌 수 없습니다.");

        } catch (ArrayIndexOutOfBoundsException e) {
            IO.println("index를 다시 확인해주세요.");
        }
    }

    public static void exception06() {
        try {
            int[] a = {1, 2, 3, 4, 5};
            IO.println(a[5]);

        } catch (ArithmeticException e) {
            IO.println(e.getMessage());

        } catch (ArrayIndexOutOfBoundsException e) {
            IO.println(e.getMessage());
        }
    }

    public static void exception07() {
        try {
            int[] a = {1, 2, 3, 4, 5};
            IO.println(a[5]);

        } catch (ArithmeticException e) {
            IO.println("0으로 나눌 수 없습니다.");

        } catch (ArrayIndexOutOfBoundsException e) {
            IO.println("index를 다시 확인해주세요.");

        } catch (Exception e) {
            IO.println("알 수 없는 예외가 발생했습니다.");
        }
    }

    public static void exception08() {
        try {
            int[] a = {1, 2, 3, 4, 5};
            IO.println(a[5]);
        } catch (Exception e) {
            IO.println("예외 발생");
        } finally {
            IO.println("프로그램 종료");
        }
    }


}
