package exception01.basic;

import java.io.IOException;

public class Exception03 {
    void main() {
        try {
            process02();

        } catch (IOException | ClassNotFoundException e) {
            System.err.println(e.getMessage());

        } finally {
            IO.println("all process ended");
        }
    }

    // throws : exception이 발생되면, 자신을 호출한 상위 process로 exception을 전달 (상위 process에서 exception 처리)
    // exception propagation (예외 전파) -> call stack 을 따라 상위로 올라감 (try-catch 를 찾을 때 까지)
    public static void process01() throws IOException {
        boolean hasExceptionOccurred = true;
        if (hasExceptionOccurred) {
            throw new IOException("예외 발생");
        }
    }

    public static void process02() throws IOException, ClassNotFoundException {
        IO.println("process02 -> process01");

        process01();

        IO.println("process02 ended");
    }
}
