package exception01.basic;

public class Exception02 {
    void main() {
        int i = inputNum();
        int j = inputNum();
        IO.println(i + j);
    }

    public static int inputNum() {
        while(true) {
            try {
                String input = IO.readln("숫자를 입력해 주세요 : ");
                return Integer.parseInt(input);
            } catch (NumberFormatException e){
                IO.println("숫자가 아닙니다.");
            }
        }
    }
}
