package functional05.optional;

import java.util.Optional;

public class Optional01 {
    void main() {
        creating();
        consuming();
        transforming();
        unwrapping();
    }

    // Optional 생성
    public static void creating() {
        // 값이 확실히 있을 때 (null이면 예외 발생)
        Optional<String> opt01 = Optional.of("Hello, World!");
        IO.println(opt01);

        // 값이 null일 수도 있을 때
        String nullableValue = (Math.random() > 0.5) ? "Data exists" : null;
        Optional<String> opt02 = Optional.ofNullable(nullableValue);
        IO.println(opt02);

        Optional<String> opt03 = Optional.empty();
        IO.println(opt03);
    }

    // 값이 있을 때만 동작 수행 (Consumer 처럼 동작)
    public static void consuming() {
        Optional<String> opt = Optional.ofNullable("java");

        // ifPresent: 값이 있을 때만 로직 실행
        opt.ifPresent(val -> IO.println(val));

        opt.ifPresentOrElse(
                val -> IO.println(val),
                () -> IO.println("null")
        );
    }

    // 값 변환 및 필터링 (Stream 처럼 동작)
    public static void transforming() {
        Optional<String> opt = Optional.of("Hello, World!");

        // filter & map
        Optional<String> result = opt.map(String::trim)
                .filter(s -> s.length() > 5)
                .map(String::toUpperCase);

        result.ifPresent(IO::println);
    }

    // default
    public static void unwrapping() {
        Optional<String> emptyOpt = Optional.empty();

        // orElse: 값이 없으면 기본값 반환
        String value01 = emptyOpt.orElse("default");
        IO.println(value01);

        // orElseGet: 값이 없을 때만 Supplier 실행
        String value02 = emptyOpt.orElseGet(() -> "default (supply)");
        IO.println(value02);

        // orElseThrow: 값이 없으면 예외 발생
        try {
            String value03 = emptyOpt.orElseThrow(() -> new IllegalArgumentException("null"));
            IO.println(value03);
        } catch (Exception e) {
            IO.println(e.getMessage());
        }
    }
}