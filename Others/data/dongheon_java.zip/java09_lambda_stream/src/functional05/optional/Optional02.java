package functional05.optional;

import java.util.List;
import java.util.Optional;

record User(String id, String name, String email) {}

public class Optional02 {
    void main() {
        handlingList();
        chaining();
    }

    public static void handlingList() {
        List<User> users = List.of(
                new User("1", "hong-gd", "hong@gd.com"),
                new User("2", "lee-ss", null)
        );

        // findAny, findFirst는 Optional을 리턴
        users.stream()
                .filter(u -> u.id().equals("1"))
                .findFirst()
                .map(User::name)
                .ifPresent(name -> IO.println(name));
    }

    public static void chaining() {
        // Optional.or : 앞의 Optional이 비어있으면 뒤의 Optional 시도
        Optional<String> primaryEmail = Optional.empty();
        Optional<String> secondaryEmail = Optional.of("admin@admin.com");

        String finalEmail = primaryEmail
                .or(() -> secondaryEmail)
                .orElse("manager@manager.com");
        IO.println(finalEmail);

        // stream() 변환 : Optional을 Stream으로 바꿔서 연속 처리 가능
        Optional<String> opt = Optional.of("Hello");
        long count = opt.stream()
                .map(String::toLowerCase)
                .count();
        IO.println(count);
    }
}