package functional04.gatherer;

import java.util.stream.Gatherer;
import java.util.stream.Stream;

public class Gatherer04 {
    void main() {
        parallelRunningSum();
    }
    public static void parallelRunningSum() {
        Gatherer<Integer, int[], Integer> parallelSum = Gatherer.of(
                () -> new int[1],
                (state, element, downstream) -> {
                    state[0] += element;
                    downstream.push(state[0]);
                    return true;
                },
                (leftState, rightState) -> {
                    leftState[0] += rightState[0];
                    return leftState;
                },
                (state, downstream) -> {}
        );

        Stream.of(1, 2, 3, 4, 5, 6, 7, 8)
                .parallel()
                .gather(parallelSum)
                .forEach(System.out::println);
    }
}
