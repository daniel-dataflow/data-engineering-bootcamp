package functional04.gatherer;

import java.util.List;
import java.util.stream.Gatherers;

public class Gathere05 {
    void main() {
        useWindowFixed();
        useWindowSliding();
        useFold();
    }

    // windowFixed (= batch)
    public static void useWindowFixed() {
        System.out.println("--- windowFixed (3) ---");
        List.of(1, 2, 3, 4, 5, 6, 7, 8)
                .stream()
                .gather(Gatherers.windowFixed(3))
                .forEach(System.out::println);
    }

    // windowSliding
    public static void useWindowSliding() {
        System.out.println("--- windowSliding (3) ---");
        List.of(1, 2, 3, 4, 5)
                .stream()
                .gather(Gatherers.windowSliding(3))
                .forEach(System.out::println);
    }

    // fold (reduce의 중간 연산 버전)
    public static void useFold() {
        List.of("A", "B", "C")
                .stream()
                .gather(Gatherers.fold(() -> "", (acc, element) -> acc + element))
                .forEach(System.out::println);
    }

    // scan: fold와 비슷하지만 중간 과정의 모든 누적치를 방출 (누적 합에 최적)
    public static void useScan() {
        List.of(1, 2, 3, 4)
                .stream()
                .gather(Gatherers.scan(() -> 0, (acc, element) -> acc + element))
                .forEach(System.out::println);
    }
}
