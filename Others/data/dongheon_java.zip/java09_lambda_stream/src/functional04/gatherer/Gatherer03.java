package functional04.gatherer;

import java.util.ArrayDeque;
import java.util.List;
import java.util.stream.Gatherer;

public class Gatherer03 {

    void main() {
        creating();
        windowing();
    }

    // sliding window Gatherer
    public static void creating() {

        Gatherer<Integer, ArrayDeque<Integer>, List<Integer>> window2 =
                Gatherer.ofSequential(
                        ArrayDeque::new,
                        (state, element, downstream) -> {
                            state.addLast(element);
                            if (state.size() == 2) {
                                downstream.push(List.copyOf(state));
                                state.removeFirst();
                            }
                            return true;
                        }
                );

        List.of(1, 2, 3, 4)
                .stream()
                .gather(window2)
                .forEach(IO::println);
    }

    public static void windowing() {

        List.of(1, 2, 3, 4, 5)
                .stream()
                .map(n -> n * 10)
                .gather(
                        Gatherer.ofSequential(
                                ArrayDeque::new,
                                (state, e, d) -> {
                                    state.addLast(e);
                                    if (state.size() == 3) {
                                        d.push(List.copyOf(state));
                                        state.removeFirst();
                                    }
                                    return true;
                                }
                        )
                )
                .forEach(IO::println);
    }
}
