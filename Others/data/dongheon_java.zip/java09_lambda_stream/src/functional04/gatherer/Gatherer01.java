package functional04.gatherer;

import java.util.List;
import java.util.stream.Gatherer;
import java.util.stream.Stream;

public class Gatherer01 {

    void main() {
        creating();
        intermediating();
    }

    public static void creating() {
        // 누적합 구해보자.
        Gatherer<Integer, int[], Integer> runningSum =
                Gatherer.ofSequential(
                        () -> new int[1],
                        (state, element, downstream) -> {
                            state[0] += element;
                            downstream.push(state[0]);
                            return true;
                        }
                );

        Stream.of(1, 2, 3, 4)
                .gather(runningSum)
                .forEach(IO::println);
    }

    public static void intermediating() {

        List<Integer> numbers = List.of(1, 2, 3, 4);

        numbers.stream()
                .map(n -> n * 2)
                .forEach(IO::println);

        // map 은 이전 정보를 알 수 없지만, gatherer 는 이전 요소의 정보를 유지 가능
        numbers.stream()
                .gather(
                        Gatherer.ofSequential(
                                () -> new int[1],
                                (state, e, d) -> {
                                    state[0] += e;
                                    d.push(state[0]);
                                    return true;
                                }
                        )
                )
                .forEach(IO::println);
    }
    /*
    Gatherer : 사용자 정의 중간 연산 (intermediate)

    기본 구조
    Gatherer<T, A, R>
        T : input type
        A : state type (반드시 mutable)
        R : output type

    Gatherer.ofSequential(
        supplier,           // 상태 초기화
        integrator,         // 각 요소별 처리
        finisher            // stream 종료 처리
    )

    * integrator : (state, element, downstream) -> boolean
    - state : 누적 상태
    - element : 현재 입력 요소
    - downstream : 다음 단계로 값 전달
    - return (true: 계속 진행 / false: stream 종료)


     */
}
