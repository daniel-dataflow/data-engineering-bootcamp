package functional04.gatherer;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Gatherer;

public class Gatherer02 {

    void main() {
        creating();
        batching();
    }

    // batch gatherer (fixed window gatherer)
    public static void creating() {
        Gatherer<Integer, List<Integer>, List<Integer>> batchOf3 =
                Gatherer.ofSequential(
                        ArrayList::new,
                        (state, element, downstream) -> {
                            state.add(element);
                            // 3개씩 모아서 처리
                            if (state.size() == 3) {
                                downstream.push(List.copyOf(state));
                                state.clear();
                            }
                            return true;
                        },
                        // 마지막에 남는 요소 처리
                        (state, downstream) -> {
                            if (!state.isEmpty()) {
                                downstream.push(List.copyOf(state));
                            }
                        }
                );

        List.of(1, 2, 3, 4, 5, 6, 7)
                .stream()
                .gather(batchOf3)
                .forEach(IO::println);
    }

    // 스트림 파이프라인에서의 활용
    public static void batching() {

        List.of(1, 2, 3, 4, 5, 6, 7)
                .stream()
                .filter(n -> n % 2 == 1)
                .gather(
                        Gatherer.ofSequential(
                                ArrayList::new,
                                (state, e, d) -> {
                                    state.add(e);
                                    if (state.size() == 2) {
                                        d.push(List.copyOf(state));
                                        state.clear();
                                    }
                                    return true;
                                },
                                (state, d) -> {
                                    if (!state.isEmpty()) {
                                        d.push(List.copyOf(state));
                                    }
                                }
                        )
                )
                .forEach(IO::println);
    }
}
