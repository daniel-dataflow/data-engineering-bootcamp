package functional03.stream;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.LongStream;

record Student(String name, String city, int score) {}
record Classroom(String className, List<Student> students) {}

public class StreamPipeline02 {
    void main() {
        flatMapping();
        collecting();
        searchingAndCounting();
        parallelProcessing();
    }

    public static void flatMapping() {
        List<Classroom> school = List.of(
                new Classroom("DS", List.of(new Student("홍길동", "서울", 80), new Student("김선달", "부산", 90))),
                new Classroom("DE", List.of(new Student("이순신", "서울", 70)))
        );

        // flatMap: 중첩된 리스트를 하나로 펼침
        List<String> allStudentNames = school.stream()
                .flatMap(cls -> cls.students().stream())
                .map(Student::name)
                .toList();
        IO.println(allStudentNames);

        school.stream()
                .flatMap(cls -> cls.students().stream())
                .mapMulti((student, consumer) -> {
                    if (student.score() >= 90) {
                        consumer.accept("* " + student.name());
                    }
                })
                .forEach(IO::println);
        IO.println();
    }

    public static void collecting() {
        List<Student> students = List.of(
                new Student("홍길동", "서울", 85),
                new Student("김선달", "부산", 92),
                new Student("이순신", "서울", 78),
                new Student("조세호", "서울", 60)
        );

        // Joining: 문자열 연결
        String names = students.stream()
                .map(Student::name)
                .collect(Collectors.joining(", ", "[", "]"));
        IO.println("연결된 이름: " + names);

        // GroupingBy: 특정 기준(도시)으로 그룹 생성
        Map<String, List<Student>> byCity = students.stream()
                .collect(Collectors.groupingBy(Student::city));
        IO.println(byCity);

        // Averaging: 특정 기준의 평균값 계산
        Map<String, Double> cityScoreAvg = students.stream()
                .collect(Collectors.groupingBy(
                        Student::city,
                        Collectors.averagingInt(Student::score)
                ));
        IO.println(cityScoreAvg);

        // PartitioningBy: 조건(80점 이상)에 따른 T/F 이분할
        Map<Boolean, List<Student>> passFail = students.stream()
                .collect(Collectors.partitioningBy(s -> s.score() >= 80));
        IO.println(passFail.get(true));
        IO.println();
    }

    public static void searchingAndCounting() {
        List<String> items = List.of("apple", "banana", "mango", "avocado");

        // anyMatch: 하나라도 조건에 맞으면 true
        boolean hasA = items.stream().anyMatch(s -> s.contains("a"));
        IO.println(hasA);

        // allMatch: 모든 요소가 조건에 맞아야 true
        boolean allStartWithA = items.stream().allMatch(s -> s.startsWith("a"));
        IO.println(allStartWithA);

        // noneMatch: 모든 요소가 조건에 맞지 않아야 true
        boolean noneMatchZ = items.stream().noneMatch(s -> s.contains("z"));
        IO.println(noneMatchZ);

        long countStartsA = items.stream()
                .filter(s -> s.startsWith("a"))
                .count();
        IO.println(countStartsA);

        long totalCount = items.stream().filter(_ -> true).count();
        IO.println(totalCount);
    }

    public static void parallelProcessing() {
        long limit = 10_000_000;

        // 순차 스트림 (Sequential)
        long start = System.currentTimeMillis();
        long sum01 = LongStream.rangeClosed(1, limit)
                .sum();
        IO.println(sum01);
        IO.println((System.currentTimeMillis() - start) + "ms");

        // 병렬 스트림 (Parallel)
        start = System.currentTimeMillis();
        long sum02 = LongStream.rangeClosed(1, limit)
                .parallel() // 병렬 스트림으로 전환
                .sum();
        IO.println(sum02);
        IO.println((System.currentTimeMillis() - start) + "ms");
    }
}