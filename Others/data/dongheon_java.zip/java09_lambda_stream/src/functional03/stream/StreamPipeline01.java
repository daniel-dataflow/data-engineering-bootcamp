package functional03.stream;

import java.util.Comparator;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class StreamPipeline01 {
    void main() {
        creating();
        intermediating();
        reducing();
    }

    public static void creating() {
        // 정적 팩토리 메서드: 고정된 데이터 셋
        Stream<String> stream01 = Stream.of("hong-gd", "kim-sd", "lee-ss");
        stream01.forEach(IO::println);

        // 빈 스트림: null 대신 반환하여 NullPointerException 방지
        Stream<String> stream02 = Stream.empty();
        stream02.forEach(IO::println);

        // 무한 스트림 (Infinite): 조건이 없으면 멈추지 않음
        Stream<Integer> stream03 = Stream.iterate(1, n -> n < 10, n -> n + 2);
        stream03.forEach(IO::println);

        // 숫자 전용 스트림 (Primitive Streams): 메모리 효율적
        IntStream stream04 = IntStream.of(1, 2, 3);
        stream04.forEach(IO::println);

        // Builder 패턴: 로직에 따라 동적으로 요소를 추가할 때
        Stream.Builder<String> builder = Stream.builder();
        builder.add("1 ").add("2 ");
        if (Math.random() > 0.5) {
            builder.add("3 ");
        }
        Stream<String> stream05 = builder.build();
        stream05.forEach(IO::print);
        IO.println();
    }

    // 중간 연산 : lazy evaluation (최종 연산이 실행되기 전까진 실행하지 않음)
    public static void intermediating() {
        var fruits = List.of("apple", "banana", "pineapple", "mango", "blueberry", "avocado");

        fruits.stream()
                .filter(s -> s.startsWith("a"))
                .map(String::toUpperCase)
                .peek(_ -> IO.println("log"))
                .sorted(Comparator.reverseOrder())
                .distinct()
                .limit(2)
                .forEach(IO::println);
        /*
        .filter     조건
        .map        변환
        .peek       로그
        .sorted     정렬
        .distinct   중복 제거
        .limit      갯수 제한
        .forEach    최종 연산
         */
    }

    // reduce : 집계 연산 (최종 연산)
    public static void reducing() {
        List<Integer> prices = List.of(1500, 3200, 800, 5000);
        int total = prices.stream().reduce(0, (a, b) -> a + b);
        IO.println(total);

        prices.stream()
                .reduce(Integer::max)
                .ifPresent(max -> IO.println("max : " + max));

        int count = prices.stream()
                .map(_ -> 1)
                .reduce(0, Integer::sum);
        IO.println("count : " + count);
    }
}
