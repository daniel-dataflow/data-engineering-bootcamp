package functional02.stream;

import java.util.function.BinaryOperator;
import java.util.function.IntBinaryOperator;
import java.util.function.IntFunction;
import java.util.function.UnaryOperator;

public class Functional01 {
    void main() {
        unary();
        binary01();
        binary02();
    }

    public static void unary() {
        UnaryOperator<String> hello = (name) -> "Hello, " + name;

        IO.println(hello.apply("Lambda"));
    }

    public static void binary01() {
        BinaryOperator<Integer> sum = (i, j) -> i + j;
        IO.println(sum.apply(10, 3));

        // apply 후 andThen 실행
        IO.println(sum.andThen((n)->n * 2).apply(10, 3));
    }

    public static void binary02() {
        IntBinaryOperator sum = (i, j) -> i + j;
        IO.println(sum.applyAsInt(10, 3));

        IntFunction<Integer> doubledSum = n -> n * 2;
        IO.println(doubledSum.apply(sum.applyAsInt(10, 3)));
    }
}
