package functional02.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.function.*;

public class MethodReference {
    void main() {
        staticMethodRef();
        boundObjRef();
        unBoundObjRef();
        constructorRef();
    }

    // 1. Static Method Reference: 클래스명::정적메서드
    public static void staticMethodRef() {
        // (s) -> Integer.parseInt(s)
        Function<String, Integer> parser = Integer::parseInt;
        IO.println((parser.apply("100") + 50));

        // (s) -> IO.println(s)
        Consumer<String> printer = IO::println;
        printer.accept("static method reference");
    }

    // 2. Bound Object Reference: 이미 존재하는 특정 객체::메서드
    public static void boundObjRef() {
        String greeting = "Hello, ";
        // 이미 생성된 greeting 이라는 '특정 객체'의 메서드를 참조
        // (s) -> greeting.concat(s)
        UnaryOperator<String> sayHello = greeting::concat;

        IO.println(sayHello.apply("World!"));
    }

    // 3. Unbound Object Reference: 클래스명::인스턴스메서드
    // (첫 번째 매개변수가 메서드의 주인이 됨)
    public static void unBoundObjRef() {
        // (s) -> s.length()
        // 특정 객체가 정해지지 않았고, 나중에 들어올 '임의의 객체(Unbound)'의 메서드를 쓰겠다는 뜻
        Function<String, Integer> getLength = String::length;

        IO.println(getLength.apply("unbound object reference"));

        // (s1, s2) -> s1.compareTo(s2)
        BiFunction<String, String, Integer> compareStrings = String::compareTo;
        IO.println(compareStrings.apply("apple", "banana"));
    }

    // 4. Constructor Reference: 클래스명::new
    public static void constructorRef() {
        // () -> new ArrayList<String>()
        Supplier<List<String>> listFactory = ArrayList::new;
        List<String> list = listFactory.get();
        list.add("Constructor");
        list.add("Reference");

        IO.println(list);
    }
}