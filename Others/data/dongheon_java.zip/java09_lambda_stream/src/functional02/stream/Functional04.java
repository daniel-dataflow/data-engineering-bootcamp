package functional02.stream;

import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class Functional04 {
	void main() {
		// supplier
		Supplier<Integer> rnum = () -> (int) (Math.random()*45) + 1;
		IO.println(rnum.get());

		// consumer
		Consumer<String> hello = (name) -> IO.println("Hello, " + name);
		hello.accept("Lambda");

		// biconsumer
		BiConsumer<String, Integer> student = (subject, score) -> IO.println(String.format("[%s] 점수 : %d", subject, score));
		student.accept("홍길동", 100);

		// unnamed variable (_) : lmabda 에서 정의는 해야 하지만 사용하지는 않을 때
		BiConsumer<String, Integer> logger = (_, score) -> IO.println("[익명] 점수 : " + score);
		logger.accept("아무거나", 95);
	}
}
