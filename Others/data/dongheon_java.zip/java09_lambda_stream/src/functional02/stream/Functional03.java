package functional02.stream;

import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.IntFunction;

public class Functional03 {
	void main() {
		func01();
		func02();
	}

	public static void func01() {
		// Function<Integer, String> time = n -> (n < 10)? "0"+ n : "" + n;
		IntFunction<String> time = n -> (n < 10) ? "0" + n : String.valueOf(n);
		IO.println(time.apply(1));
		IO.println(time.apply(3));
		IO.println(time.apply(6));
		IO.println(time.apply(10));
	}

	public static void func02() {
		BiFunction<String, String, Integer> sum = (i, j) -> Integer.parseInt(i) + Integer.parseInt(j);
		IO.println(sum.apply("10", "20"));
	}
}
