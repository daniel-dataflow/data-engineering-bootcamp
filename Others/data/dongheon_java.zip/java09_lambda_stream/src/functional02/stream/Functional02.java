package functional02.stream;

import java.util.function.BiPredicate;
import java.util.function.IntPredicate;
import java.util.function.Predicate;

public class Functional02 {
	void main() {
		predic01();
		predic02();
		predic03();
	}

	public static boolean isNull(String name, Predicate<String> predic) {
		return predic.test(name);
	}
	
	public static void predic01() {
		String name = null;
		while (true) {
			name = IO.readln("이름 입력 : ");

			if (isNull(name, (input) -> input.trim().length() == 0)) {
				IO.println("다시 입력해 주세요.");
			} else {
				break;
			}
		}
		IO.println("제 이름은 " + name + "입니다. ");
	}
	
	public static void predic02() {
		// Predicate<Integer> p2 = (n) -> n % 2 == 0;
		IntPredicate p2 = n -> n % 2 == 0;
		IntPredicate p3 = (n) -> n % 3 == 0;

		int input = Integer.parseInt(IO.readln("숫자를 입력해 주세요 : "));
		if (p2.test(input)) {
			IO.println(input + ": 2의 배수 입니다.");
		}
		if (p3.test(input)) {
			IO.println(input + ": 3의 배수 입니다.");
		}

		// negating(부정) : 2의 배수가 아닐 때
		if (p2.negate().test(input)) IO.println(input + ": 홀수입니다.");

		// and 연산
		if (p2.and(p3).test(input)) {
			IO.println(input + ": 2와 3의 공배수(6의 배수)입니다.");
		}
	}
	
	public static void predic03() {
		BiPredicate<Integer, Integer> bp01 = (i, j) -> i - j > 0;
		int i = Integer.parseInt(IO.readln("i를 입력해 주세요 : "));
		int j = Integer.parseInt(IO.readln("j를 입력해 주세요 : "));

		IO.println(bp01.test(i, j) ? "i > j" : "i <= j");
	}
}
