package functional01.lambda;

public class Lambda02 {
    void main() {
        /*
        () -> expression
        () -> {statements}
        parameter -> expression
        parameter -> {statements}
        (parameter) -> expression
        (parameter) -> {statements}
        (parameters) -> expression
        (parameters) -> {statements}

        expression 은 return 생략, statements는 return 생략 불가!
         */
        Parameter00 param01 = () -> IO.println("parameter의 개수가 0개");
        param01.prn();

        Parameter01 param02 = () -> "parameter의 개수가 0개";
        IO.println(param02.prn());

        Parameter10 param10 = i -> IO.println(i + 1);
        param10.prn(10);

        Parameter11 param11 = (i) -> {int result = 1 + 3; return result; };
        IO.println(param11.prn(11));

        Parameter20 param20 = (i, j) -> IO.println(i + j);
        param20.prn(2, 10);

        Parameter21 param21 = (i, j) -> i + j;
        IO.println(param21.prn(20, 1));
    }
}
