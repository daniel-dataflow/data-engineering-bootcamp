package functional01.lambda;

// 생략 가능 -> 생략하면 여러개의 method가 들어갈 수도 있으니 작성해주자 -> 추가해주면 compiler가 2개 이상이면 에러 발생
// @FunctionalInterface
public interface Parameter01 {
    String prn();
}
