package functional01.lambda;

public interface Calculator {
    double calc(double a, double b);
}
