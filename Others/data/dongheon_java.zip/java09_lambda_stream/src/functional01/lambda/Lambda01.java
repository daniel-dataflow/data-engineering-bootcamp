package functional01.lambda;

public class Lambda01 {
    void main() {
        // 기존 방식
        Calculator sum = new Calculator() {
            @Override
            public double calc(double a, double b) {
                return a + b;
            }
        };

        IO.println(sum.calc(1.2, 3.4));

        // lambda
        Calculator sub = (a, b) -> a - b;
        IO.println(sub.calc(5.4, 3.2));
    }
}
