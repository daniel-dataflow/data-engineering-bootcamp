package functional01.lambda;

// @FunctionalInterface : 단 하나의 abstract method를 가진 interface를 의미!
@FunctionalInterface
public interface Parameter00 {
    void prn();
}
