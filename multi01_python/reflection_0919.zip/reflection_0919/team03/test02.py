purchases = [{"name": "김예은", "cart": ["banana", "apple"]},
            {"name": "이은지", "cart": ["apple", "jelly"]}]

products = [{"banana": 3500, "apple": 3000, "jelly": 2000}]

"""
원하는 출력값

김예은 6500원 사용했습니다.
이은지 5000원 사용했습니다.
"""
