import re

# 문자열 리스트 요소 5개 0~4
# t or T라는 단어가 들어가있는 단어 골라서 반환

# 문자열 리스트
ex_list = ["Mint", "SamDaSoo", "Lettteee", "MAmaTmamama", "reesefg"]
"""
출력예시
Mint
Lettteee
MAmaTmamama
"""