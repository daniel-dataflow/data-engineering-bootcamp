from random import randint

# 문2] 입력한 숫자와 랜덤한 숫자(10)가 일치하면 승, 15 입력하면 종료


def game_process(player_num: int) -> None:
    pass


def play() -> None:
    pass


if __name__ == '__main__':
    play()
