from random import shuffle
# 사다리 타기

# 입력 값을 받는다.
# 동일한 갯수의 출력값을 받는다.
# 서로 랜덤으로 매칭을 시킨다.
# 결과 값을 짝 지어서 출력한다.

def ladder(people_list, choice_list):
    pass


if __name__ == '__main__':
    pass
