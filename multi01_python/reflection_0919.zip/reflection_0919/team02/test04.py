# 2개의 자연수를 입력받아 최대공약수와 최대공배수를 구하는 함수를 구현하세요
# recursion 활용
# *Euclidean algorithm(유클리드 호제법)* 검색 시 쉽게 구현가능!

"""
자연수를 입력하세요: 10
또다른 자연수를 입력하세요: 20
최대공약수: 10
최소공배수: 20
"""

def min_devisor(i: int, j: int) -> int:
    pass

def max_multiple(i: int, j: int) -> int:
    pass

def print_result(i: int, j: int) -> None:
    pass


if __name__ == "__main__":
    a = int(input("자연수를 입력하세요: "))
    b = int(input("또다른 자연수를 입력하세요: "))
    print_result(a, b)