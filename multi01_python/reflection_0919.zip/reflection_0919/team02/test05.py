from random import randint

# 생년월일과 성별을 입력받아 주민등록번호를 완성하세요
# 뒤의 6자리는 랜덤한 숫자를 부여한다
# random 모듈, **kwargs, format() 활용

"""
몇년도에 태어나셨습니까? 2001
몇월에 태어나셨습니까? 2
몇일에 태어났습니까? 13
성별이 무엇입니까(남/여)? 남
주민등록번호: 010213-3124579
"""

def resident_number(**kwargs) -> None:
    pass

if __name__ == "__main__":
    pass
