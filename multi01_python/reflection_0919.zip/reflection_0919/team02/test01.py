"""
#####
 ###
  #
*****
*****
*****
  @
 @@@
@@@@@

"""
def diagram1():
    pass

def diagram2():
    pass

def diagram3():
    pass

if __name__ == '__main__':
    diagram1()
    diagram2()
    diagram3()





